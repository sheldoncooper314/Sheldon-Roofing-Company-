# Sheldon Roofing Company: local-contractor website template

A TanStack Start site for a roofing contractor, built to be re-skinned for the next one.
Visitors can request an estimate, book a flat-fee inspection or tune-up, and pay a project
deposit. The contractor can then bill the final balance. Payments run through Whop, so
card data never touches this site.

## Reusing this template

**Every piece of business content lives in one file: `src/site.config.ts`.** To pitch the
same site to another roofer, edit that file and nothing else:

| Section in `site.config.ts` | What it controls |
|---|---|
| `name`, `shortName`, `tagline`, `seoTitle`, `seoDescription`, `siteUrl` | Brand name, page titles, meta description (set `siteUrl` once the domain is known) |
| `logoUrl`, `heroImageUrl`, `heroImageAlt` | Logo and hero photo (use absolute URLs; the hero is also the `og:image`) |
| `phone`, `phoneHref`, `email`, `street`, `city`, `state`, `postalCode`, `hours`, `emergencyLine`, `licenseNumber` | Contact details (placeholders until confirmed) |
| `hero`, `trustBadges`, `warrantyYears` | Hero copy and the trust bar |
| `accountId` | The Whop business (`biz_…`) that receives payments, leads and invoices |
| `plans` | The three purchasable plans: `inspection`, `deposit`, `tuneUp`. Each has a Whop `productId` and a `plan_…` id, a price and checkout copy |
| `services`, `flatRate`, `steps` | The three service cards, the flat-rate offer, and the how-it-works steps |
| `serviceArea`, `financing`, `reviews`, `faq` | Service area, financing blurb, reviews (flagged as sample until `isSample` is `false`), FAQ |
| `estimateForm` | Service dropdown options and the optional product each service maps to for leads |
| `finalInvoice` | Wording and due date for the final-balance invoice |

Anything in `site.config.ts` that is not confirmed with the business (licence wording,
phone, reviews, cities, hours) is a placeholder. Replace it before launch. The LocalBusiness
JSON-LD and the page `<head>` are generated from the same file.

To change the look, edit the design tokens at the top of `src/styles.css` (navy, orange,
paper colours and the two font families).

### Whop setup for a new business

1. Create the three products and plans in the new Whop business (an inspection fee, a project
   deposit and a flat-rate tune-up), then paste their ids into `plans` and the business id into
   `accountId`.
2. Do not put API keys in the code. Server functions read `WHOP_API_KEY` from the Worker
   environment; the hosting platform injects the company key at the network edge.
3. Set the app secrets below.

### Secrets

| Name | Required | Used for |
|---|---|---|
| `ADMIN_DEMO_KEY` | Only for `/admin/final-invoice` | Shared key that unlocks the contractor tool. Pick a long random value. Without it the page shows setup instructions and nobody can use it. |
| `SESSION_SECRET` | Optional | Signs the short-lived cookies (admin unlock, saved deposit card). Falls back to a value derived from `ADMIN_DEMO_KEY`. |

Set them with:

```bash
whop apps secrets set --app <app_id> --secret ADMIN_DEMO_KEY=<long-random-value>
```

or under Settings → Secrets for the website. Allow a few seconds, then reload.

### What the site does

- **Estimate form** creates a Whop lead for the account. Whop leads must belong to a Whop
  user, and a first-time visitor has none, so the lead is attached to the visitor if their
  email already matches a member, otherwise to the account's admin. The visitor's name,
  email, phone, address and message are always stored in the lead's metadata.
- **Book Inspection / Book Tune-Up** open an embedded Whop checkout (Apple Pay / Google Pay
  when available, plus card and other methods).
- **Pay Deposit** saves the card with a setup intent, then charges the deposit plan to it.
  Saving the card for the final balance is opt-in.
- **`/admin/final-invoice`** (contractor tool / demo) creates a Whop invoice for the remaining
  balance, either charged to the saved card or emailed for manual payment.
- **Tracking:** events are sent through `window.whop.track` (no extra pixel). Set
  `localStorage.debugTracking = "1"` to log them to the console as `[whop.track]`.

# Getting Started

To run this application:

```bash
bun install
bun --bun run dev
```

# Building For Production

To build this application for production:

```bash
bun --bun run build
```

## Styling

This project uses [Tailwind CSS](https://tailwindcss.com/) for styling.

### Removing Tailwind CSS

If you prefer not to use Tailwind CSS:

1. Remove the demo pages in `src/routes/demo/`
2. Replace the Tailwind import in `src/styles.css` with your own styles
3. Remove `tailwindcss()` from the plugins array in `vite.config.ts`
4. Remove `@tailwindcss/vite` and `tailwindcss` from `package.json`


## Deploy to Cloudflare Workers

This project uses the Cloudflare Vite plugin (configured in `vite.config.ts`) and `wrangler.jsonc`:

1. Install Wrangler: `npm install -g wrangler`
2. Authenticate: `wrangler login`
3. Deploy: `npx wrangler deploy`

For production env vars, run `wrangler secret put MY_VAR` for each secret listed in `.env.example`. Public (non-secret) vars go in `wrangler.jsonc` under `vars`.

KV, D1, R2, and Durable Object bindings are configured in `wrangler.jsonc` — see https://developers.cloudflare.com/workers/wrangler/configuration/.



## Routing

This project uses [TanStack Router](https://tanstack.com/router) with file-based routing. Routes are managed as files in `src/routes`.

### Adding A Route

To add a new route to your application just add a new file in the `./src/routes` directory.

TanStack will automatically generate the content of the route file for you.

Now that you have two routes you can use a `Link` component to navigate between them.

### Adding Links

To use SPA (Single Page Application) navigation you will need to import the `Link` component from `@tanstack/react-router`.

```tsx
import { Link } from "@tanstack/react-router";
```

Then anywhere in your JSX you can use it like so:

```tsx
<Link to="/about">About</Link>
```

This will create a link that will navigate to the `/about` route.

More information on the `Link` component can be found in the [Link documentation](https://tanstack.com/router/v1/docs/framework/react/api/router/linkComponent).

### Using A Layout

In the File Based Routing setup the layout is located in `src/routes/__root.tsx`. Anything you add to the root route will appear in all the routes. The route content will appear in the JSX where you render `{children}` in the `shellComponent`.

Here is an example layout that includes a header:

```tsx
import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'My App' },
    ],
  }),
  shellComponent: ({ children }) => (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <header>
          <nav>
            <Link to="/">Home</Link>
            <Link to="/about">About</Link>
          </nav>
        </header>
        {children}
        <Scripts />
      </body>
    </html>
  ),
})
```

More information on layouts can be found in the [Layouts documentation](https://tanstack.com/router/latest/docs/framework/react/guide/routing-concepts#layouts).

## Server Functions

TanStack Start provides server functions that allow you to write server-side code that seamlessly integrates with your client components.

```tsx
import { createServerFn } from '@tanstack/react-start'

const getServerTime = createServerFn({
  method: 'GET',
}).handler(async () => {
  return new Date().toISOString()
})

// Use in a component
function MyComponent() {
  const [time, setTime] = useState('')
  
  useEffect(() => {
    getServerTime().then(setTime)
  }, [])
  
  return <div>Server time: {time}</div>
}
```

## API Routes

You can create API routes by using the `server` property in your route definitions:

```tsx
import { createFileRoute } from '@tanstack/react-router'
import { json } from '@tanstack/react-start'

export const Route = createFileRoute('/api/hello')({
  server: {
    handlers: {
      GET: () => json({ message: 'Hello, World!' }),
    },
  },
})
```

## Data Fetching

There are multiple ways to fetch data in your application. You can use TanStack Query to fetch data from a server. But you can also use the `loader` functionality built into TanStack Router to load the data for a route before it's rendered.

For example:

```tsx
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/people')({
  loader: async () => {
    const response = await fetch('https://swapi.dev/api/people')
    return response.json()
  },
  component: PeopleComponent,
})

function PeopleComponent() {
  const data = Route.useLoaderData()
  return (
    <ul>
      {data.results.map((person) => (
        <li key={person.name}>{person.name}</li>
      ))}
    </ul>
  )
}
```

Loaders simplify your data fetching logic dramatically. Check out more information in the [Loader documentation](https://tanstack.com/router/latest/docs/framework/react/guide/data-loading#loader-parameters).



# Learn More

You can learn more about all of the offerings from TanStack in the [TanStack documentation](https://tanstack.com).

For TanStack Start specific documentation, visit [TanStack Start](https://tanstack.com/start).
