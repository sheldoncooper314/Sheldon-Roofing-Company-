import { useEffect, useState, type ReactNode } from 'react'
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { WhopElements } from '@whop/elements-react'
import { formatUsd, getPlan, isPlanKey, site, type PlanKey } from '#/site.config'
import { seo } from '#/lib/seo'
import { SiteHeader } from '#/components/SiteHeader'
import { SiteFooter } from '#/components/SiteFooter'
import { useCheckout } from '#/components/CheckoutProvider'
import { DepositChargeStep, elementsAppearance, getElements } from '#/components/CheckoutModal'
import { CheckIcon } from '#/components/Icons'

interface Search {
  plan?: PlanKey
  status?: string
  payment?: string
  setup?: string
  client_secret?: string
}

const str = (v: unknown) => (typeof v === 'string' && v ? v : undefined)

export const Route = createFileRoute('/thank-you')({
  staticData: { pageId: 'pg_t3n9y0uq8c2z' },
  validateSearch: (s: Record<string, unknown>): Search => ({
    plan: isPlanKey(s.plan) ? s.plan : undefined,
    status: str(s.status),
    payment: str(s.payment),
    setup: str(s.setup),
    client_secret: str(s.client_secret),
  }),
  head: () => ({
    meta: seo({
      title: `Order status — ${site.name}`,
      description: `Your payment status with ${site.name}.`,
      path: '/thank-you',
      noindex: true,
    }),
  }),
  component: ThankYou,
})

function Shell({ children }: { children: ReactNode }) {
  return (
    <>
      <SiteHeader />
      <main className="min-h-[70vh] py-14 sm:py-20">
        <div className="wrap max-w-2xl">{children}</div>
      </main>
      <SiteFooter />
    </>
  )
}

function ThankYou() {
  const search = Route.useSearch()
  const navigate = useNavigate()
  const { openCheckout } = useCheckout()
  const plan = search.plan ? getPlan(search.plan) : null
  const status = search.status

  // The browser can only render Whop Elements after mount.
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  // A card save that finished after an off-site step lands here with `setup=sint_…`.
  const cardJustSaved =
    search.plan === 'deposit' && status === 'succeeded' && !search.payment && search.setup && search.client_secret

  if (cardJustSaved && search.setup && search.client_secret) {
    const returnUrl = `${typeof window === 'undefined' ? site.siteUrl : window.location.origin}/thank-you?plan=deposit`
    return (
      <Shell>
        <p className="eyebrow">Step 2 of 2</p>
        <h1 className="h-section mt-2">Card saved. Now the deposit.</h1>
        <div className="card mt-8 bg-card p-6">
          {mounted ? (
            <WhopElements elements={getElements()} appearance={elementsAppearance}>
              <DepositChargeStep
                setupIntentId={search.setup}
                clientSecret={search.client_secret}
                returnUrl={returnUrl}
                onFinish={(finalStatus, paymentId) =>
                  void navigate({
                    to: '/thank-you',
                    search: { plan: 'deposit', status: finalStatus, payment: paymentId },
                    replace: true,
                  })
                }
              />
            </WhopElements>
          ) : (
            <p className="text-ink-soft">Loading…</p>
          )}
        </div>
      </Shell>
    )
  }

  // Only an explicit "succeeded" counts as success. Anyone can type a URL.
  if (status === 'succeeded') {
    return (
      <Shell>
        <div role="status" className="card bg-card p-7 text-center sm:p-10">
          <span className="mx-auto grid size-16 place-items-center rounded-full bg-ok text-white">
            <CheckIcon className="size-8" />
          </span>
          <p className="eyebrow mt-6">Payment received</p>
          <h1 className="h-section mt-2">Thank you.</h1>
          {plan ? (
            <p className="mt-4 font-semibold text-navy-900">
              {plan.title} · {formatUsd(plan.price)}
            </p>
          ) : null}
          <p className="mx-auto mt-3 max-w-md text-ink-soft">
            {plan?.thanks ?? 'We will be in touch shortly with next steps.'}
          </p>
          {search.payment ? (
            <p className="mt-5 inline-block rounded-md bg-paper-deep px-3 py-2 text-xs font-semibold text-ink-soft">
              Payment reference: <span className="font-mono text-navy-900">{search.payment}</span>
            </p>
          ) : null}
          <p className="mt-4 text-sm text-ink-soft">A receipt is on its way to your email from Whop.</p>
          <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
            <Link to="/" className="btn btn-navy">
              Back to {site.shortName}
            </Link>
            <a href={site.phoneHref} className="btn btn-ghost">
              Call {site.phone}
            </a>
          </div>
        </div>
      </Shell>
    )
  }

  if (status === 'failed' || status === 'canceled') {
    return (
      <Shell>
        <div role="alert" className="card bg-card p-7 text-center sm:p-10">
          <p className="eyebrow !text-bad">Payment not completed</p>
          <h1 className="h-section mt-2">That did not go through.</h1>
          <p className="mx-auto mt-4 max-w-md text-ink-soft">
            No money was taken. You can try again with a different payment method, or call us and we will take care of it.
          </p>
          <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
            {search.plan ? (
              <button type="button" className="btn btn-primary" onClick={() => openCheckout(search.plan!)}>
                Try again
              </button>
            ) : (
              <Link to="/" className="btn btn-primary">
                Back to {site.shortName}
              </Link>
            )}
            <a href={site.phoneHref} className="btn btn-ghost">
              Call {site.phone}
            </a>
          </div>
        </div>
      </Shell>
    )
  }

  if (status) {
    return (
      <Shell>
        <div role="status" className="card bg-card p-7 text-center sm:p-10">
          <p className="eyebrow">Processing</p>
          <h1 className="h-section mt-2">Confirming your payment.</h1>
          <p className="mx-auto mt-4 max-w-md text-ink-soft">
            Your payment is still being processed. You do not need to pay again. Whop will email your receipt as soon as it is
            confirmed.
          </p>
          {search.payment ? (
            <p className="mt-5 inline-block rounded-md bg-paper-deep px-3 py-2 text-xs font-semibold text-ink-soft">
              Payment reference: <span className="font-mono text-navy-900">{search.payment}</span>
            </p>
          ) : null}
          <div className="mt-7">
            <Link to="/" className="btn btn-navy">
              Back to {site.shortName}
            </Link>
          </div>
        </div>
      </Shell>
    )
  }

  return (
    <Shell>
      <div className="card bg-card p-7 text-center sm:p-10">
        <h1 className="h-section">Nothing to show here.</h1>
        <p className="mx-auto mt-4 max-w-md text-ink-soft">This page appears after a payment. Start from the home page.</p>
        <div className="mt-7">
          <Link to="/" className="btn btn-primary">
            Back to {site.shortName}
          </Link>
        </div>
      </div>
    </Shell>
  )
}
