import { createFileRoute } from '@tanstack/react-router'
import { site } from '#/site.config'
import { seo, localBusinessJsonLd } from '#/lib/seo'
import { SiteHeader } from '#/components/SiteHeader'
import { SiteFooter } from '#/components/SiteFooter'
import { Hero } from '#/components/Hero'
import { TrustBar } from '#/components/TrustBar'
import { Services } from '#/components/Services'
import { HowItWorks } from '#/components/HowItWorks'
import { ServiceArea } from '#/components/ServiceArea'
import { Financing } from '#/components/Financing'
import { Reviews } from '#/components/Reviews'
import { Faq } from '#/components/Faq'
import { EstimateForm } from '#/components/EstimateForm'

export const Route = createFileRoute('/')({
  staticData: { pageId: 'pg_h7k2m9qa4tw3' },
  head: () => ({
    meta: seo({ title: site.seoTitle, description: site.seoDescription, path: '/' }),
    scripts: [{ type: 'application/ld+json', children: JSON.stringify(localBusinessJsonLd()) }],
  }),
  component: Home,
})

function Home() {
  return (
    <>
      <a
        href="#main"
        className="sr-only z-50 rounded-md bg-navy-900 px-4 py-3 font-bold text-white focus:not-sr-only focus:fixed focus:top-3 focus:left-3"
      >
        Skip to content
      </a>
      <SiteHeader />
      <main id="main">
        <Hero />
        <TrustBar />
        <Services />
        <HowItWorks />
        <ServiceArea />
        <Financing />
        <Reviews />
        <Faq />
        <EstimateForm />
      </main>
      <SiteFooter />
    </>
  )
}
