import { HeadContent, Outlet, Scripts, createRootRoute, Link } from '@tanstack/react-router'
import { site } from '#/site.config'
import { CheckoutProvider } from '#/components/CheckoutProvider'

import appCss from '../styles.css?url'

const FONTS_HREF =
  'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700;800&family=Manrope:wght@400;500;600;700;800&display=swap'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { name: 'color-scheme', content: 'light' },
      { name: 'theme-color', content: '#14213d' },
      { title: site.seoTitle },
      { name: 'description', content: site.seoDescription },
    ],
    links: [
      { rel: 'icon', href: site.logoUrl },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      { rel: 'stylesheet', href: FONTS_HREF },
      { rel: 'stylesheet', href: appCss },
    ],
  }),
  shellComponent: RootDocument,
  component: RootLayout,
  notFoundComponent: NotFound,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" style={{ colorScheme: 'light' }}>
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  )
}

function RootLayout() {
  return (
    <CheckoutProvider>
      <Outlet />
    </CheckoutProvider>
  )
}

function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center px-6 text-center">
      <div>
        <p className="eyebrow">404</p>
        <h1 className="h-section mt-2">That page is off the roof.</h1>
        <p className="mx-auto mt-4 max-w-md text-ink-soft">The page you were looking for does not exist.</p>
        <Link to="/" className="btn btn-primary mt-6">
          Back to {site.shortName}
        </Link>
      </div>
    </main>
  )
}
