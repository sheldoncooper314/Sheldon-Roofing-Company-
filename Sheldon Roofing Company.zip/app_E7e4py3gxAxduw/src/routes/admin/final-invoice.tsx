import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react'
import { createFileRoute, Link, useRouter } from '@tanstack/react-router'
import { formatUsd, getPlan, site } from '#/site.config'
import { seo } from '#/lib/seo'
import {
  adminLockFn,
  adminStatusFn,
  adminUnlockFn,
  createFinalInvoiceFn,
  type AdminStatus,
  type InvoiceSummary,
} from '#/lib/invoice.functions'
import { LogoMark } from '#/components/SiteHeader'
import { LockIcon } from '#/components/Icons'

export const Route = createFileRoute('/admin/final-invoice')({
  staticData: { pageId: 'pg_a5d1m7n3x8vk' },
  loader: () => adminStatusFn(),
  head: () => ({
    meta: seo({
      title: `Final balance invoice (contractor tool) — ${site.name}`,
      description: 'Internal demo tool for billing a roofing job’s final balance.',
      path: '/admin/final-invoice',
      noindex: true,
    }),
  }),
  component: FinalInvoicePage,
})

function Shell({ children, onLock }: { children: ReactNode; onLock?: () => void }) {
  return (
    <div className="min-h-screen bg-paper-deep">
      <header className="border-b-2 border-navy-900 bg-navy-900 text-white">
        <div className="wrap flex h-16 items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-3">
            <LogoMark size={40} />
            <span className="font-display text-2xl font-extrabold tracking-wide uppercase">{site.shortName}</span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="rounded bg-ember-500 px-2.5 py-1 text-xs font-extrabold tracking-widest uppercase">
              Contractor tool / demo
            </span>
            {onLock ? (
              <button type="button" onClick={onLock} className="btn btn-ghost-light btn-sm">
                Lock
              </button>
            ) : null}
          </div>
        </div>
      </header>
      <main className="wrap max-w-3xl py-10 sm:py-14">{children}</main>
    </div>
  )
}

function FinalInvoicePage() {
  const status = Route.useLoaderData() as AdminStatus
  const router = useRouter()

  async function lock() {
    await adminLockFn()
    await router.invalidate()
  }

  if (!status.configured) {
    return (
      <Shell>
        <div className="card bg-card p-7">
          <p className="eyebrow">Setup needed</p>
          <h1 className="mt-2 text-5xl text-navy-900 uppercase">Set ADMIN_DEMO_KEY</h1>
          <p className="mt-4 text-ink-soft">
            This page is locked with a shared secret that is read from the app secret <code className="font-mono font-bold">ADMIN_DEMO_KEY</code>.
            It is not set yet, so nobody can use the tool. Add it, wait a few seconds, then reload:
          </p>
          <pre className="mt-4 overflow-x-auto rounded-md bg-navy-950 p-4 text-sm break-words whitespace-pre-wrap text-white">
            whop apps secrets set --app {'<this app id>'} --secret ADMIN_DEMO_KEY=choose-a-long-random-value
          </pre>
          <p className="mt-3 text-sm text-ink-soft">Or paste it under Settings → Secrets for this website. See the README for details.</p>
        </div>
      </Shell>
    )
  }

  if (!status.unlocked) return <Shell><Unlock onDone={() => router.invalidate()} /></Shell>

  return (
    <Shell onLock={lock}>
      <InvoiceForm browserCard={status.browserCard} />
    </Shell>
  )
}

function Unlock({ onDone }: { onDone: () => void }) {
  const [key, setKey] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function submit(event: FormEvent) {
    event.preventDefault()
    setBusy(true)
    setError(null)
    try {
      const result = await adminUnlockFn({ data: { key } })
      if (result.ok) onDone()
      else setError(result.error ?? 'Could not unlock.')
    } catch {
      setError('Could not unlock. Try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} className="card mx-auto max-w-md space-y-5 bg-card p-7">
      <div className="flex items-center gap-3">
        <LockIcon className="size-7 text-ember-600" />
        <h1 className="text-4xl text-navy-900 uppercase">Contractor tool</h1>
      </div>
      <p className="text-sm text-ink-soft">Demo page for billing a job’s final balance. Enter the shared key to continue.</p>
      <div>
        <label htmlFor="admin-key" className="field-label">
          Demo key
        </label>
        <input
          id="admin-key"
          type="password"
          autoComplete="current-password"
          className="field"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          aria-invalid={error ? true : undefined}
        />
        {error ? (
          <p role="alert" className="field-error">
            {error}
          </p>
        ) : null}
      </div>
      <button type="submit" className="btn btn-navy w-full" disabled={busy || !key}>
        {busy ? 'Checking…' : 'Unlock'}
      </button>
    </form>
  )
}

function InvoiceForm({ browserCard }: { browserCard: AdminStatus['browserCard'] }) {
  const deposit = getPlan('deposit')
  const [useBrowserCard, setUseBrowserCard] = useState(Boolean(browserCard))
  const [customer, setCustomer] = useState('')
  const [customerName, setCustomerName] = useState('')
  const [job, setJob] = useState(site.finalInvoice.example.jobDescription)
  const [jobTotal, setJobTotal] = useState('')
  const [balance, setBalance] = useState('')
  const [balanceEdited, setBalanceEdited] = useState(false)
  const [collection, setCollection] = useState<'auto' | 'send'>(browserCard?.autoChargeConsent ? 'auto' : 'send')
  const [dueInDays, setDueInDays] = useState(String(site.finalInvoice.dueInDays))
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<InvoiceSummary | null>(null)
  const [debug, setDebug] = useState(false)
  const idemKey = useRef('')

  useEffect(() => {
    idemKey.current = crypto.randomUUID()
    try {
      setDebug(window.localStorage.getItem('debugTracking') === '1')
    } catch {
      /* storage blocked */
    }
  }, [])

  function onJobTotal(value: string) {
    setJobTotal(value)
    const total = Number(value)
    if (!balanceEdited && Number.isFinite(total) && total > deposit.price) {
      setBalance((Math.round((total - deposit.price) * 100) / 100).toFixed(2))
    }
  }

  function toggleDebug(on: boolean) {
    setDebug(on)
    try {
      if (on) window.localStorage.setItem('debugTracking', '1')
      else window.localStorage.removeItem('debugTracking')
    } catch {
      /* storage blocked */
    }
  }

  async function submit(event: FormEvent) {
    event.preventDefault()
    if (busy) return
    setBusy(true)
    setError(null)
    setResult(null)
    try {
      const response = await createFinalInvoiceFn({
        data: {
          customer: useBrowserCard ? '' : customer,
          customerName: customerName || undefined,
          jobDescription: job,
          jobTotal: jobTotal ? Number(jobTotal) : undefined,
          balance: Number(balance),
          collection,
          dueInDays: Number(dueInDays) || undefined,
          useBrowserCard,
          idempotencyKey: idemKey.current,
        },
      })
      if (response.ok) {
        setResult(response.invoice)
        idemKey.current = crypto.randomUUID()
      } else {
        setError(response.error)
      }
    } catch (e) {
      setError((e as Error).message || 'The invoice could not be created.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <p className="eyebrow">Contractor tool / demo</p>
        <h1 className="mt-2 text-5xl text-navy-900 uppercase sm:text-6xl">Bill the final balance</h1>
        <p className="mt-3 max-w-xl text-ink-soft">
          The customer’s {formatUsd(deposit.price)} deposit is already paid. Enter only what is left. The invoice says so, and
          you choose how it is collected.
        </p>
      </div>

      <form onSubmit={submit} className="card space-y-6 bg-card p-5 sm:p-7">
        <fieldset className="space-y-4">
          <legend className="font-display text-2xl font-bold tracking-wide text-navy-900 uppercase">1. Customer</legend>
          {browserCard ? (
            <label className="flex min-h-11 cursor-pointer items-start gap-3 rounded-md border-2 border-navy-900 bg-paper p-3 text-sm">
              <input
                type="checkbox"
                className="mt-0.5 size-5 shrink-0 accent-[var(--color-ember-600)]"
                checked={useBrowserCard}
                onChange={(e) => setUseBrowserCard(e.target.checked)}
              />
              <span>
                <strong className="text-navy-900">Use the deposit customer from this browser</strong>
                {browserCard.emailMasked ? <span className="text-ink-soft"> ({browserCard.emailMasked})</span> : null}
                <span className="block text-ink-soft">
                  Their card was saved when the deposit was paid.{' '}
                  {browserCard.autoChargeConsent
                    ? 'They agreed to have the final balance charged to it.'
                    : 'They did not agree to auto-charge, so send them an invoice link.'}
                </span>
              </span>
            </label>
          ) : null}

          {!useBrowserCard ? (
            <>
              <div>
                <label htmlFor="inv-customer" className="field-label">
                  Customer email or member id
                </label>
                <input
                  id="inv-customer"
                  className="field"
                  placeholder="name@example.com or mber_…"
                  value={customer}
                  onChange={(e) => setCustomer(e.target.value)}
                  required
                />
              </div>
              <div>
                <label htmlFor="inv-name" className="field-label">
                  Customer name <span className="font-medium text-ink-soft">(optional)</span>
                </label>
                <input id="inv-name" className="field" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
              </div>
            </>
          ) : null}
        </fieldset>

        <fieldset className="space-y-4">
          <legend className="font-display text-2xl font-bold tracking-wide text-navy-900 uppercase">2. The job</legend>
          <div>
            <label htmlFor="inv-job" className="field-label">
              Job description
            </label>
            <textarea id="inv-job" className="field !min-h-24" value={job} onChange={(e) => setJob(e.target.value)} required />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="inv-total" className="field-label">
                Contract total <span className="font-medium text-ink-soft">(optional, to calculate)</span>
              </label>
              <input
                id="inv-total"
                type="number"
                inputMode="decimal"
                min="0"
                step="0.01"
                className="field"
                placeholder="11450.00"
                value={jobTotal}
                onChange={(e) => onJobTotal(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="inv-balance" className="field-label">
                Final balance due (USD)
              </label>
              <input
                id="inv-balance"
                type="number"
                inputMode="decimal"
                min="0.01"
                step="0.01"
                className="field"
                placeholder="10950.00"
                value={balance}
                onChange={(e) => {
                  setBalance(e.target.value)
                  setBalanceEdited(true)
                }}
                required
              />
            </div>
          </div>
          <p className="rounded-md bg-paper-deep px-3 py-2 text-sm text-ink-soft">
            Invoice note: “{formatUsd(deposit.price)} project deposit already paid and not billed again.”
          </p>
        </fieldset>

        <fieldset className="space-y-3">
          <legend className="font-display text-2xl font-bold tracking-wide text-navy-900 uppercase">3. How to collect</legend>
          {(
            [
              ['auto', 'Auto-charge card on file', 'Issues the invoice and charges the customer’s saved card right away.'],
              ['send', 'Send invoice for manual payment', 'Emails the invoice with a secure payment link, due in the days below.'],
            ] as const
          ).map(([value, title, text]) => (
            <label
              key={value}
              className={`flex min-h-11 cursor-pointer items-start gap-3 rounded-md border-2 p-3 ${
                collection === value ? 'border-navy-900 bg-paper' : 'border-paper-edge'
              }`}
            >
              <input
                type="radio"
                name="collection"
                className="mt-1 size-5 shrink-0 accent-[var(--color-ember-600)]"
                checked={collection === value}
                onChange={() => setCollection(value)}
              />
              <span>
                <strong className="block text-navy-900">{title}</strong>
                <span className="text-sm text-ink-soft">{text}</span>
              </span>
            </label>
          ))}
          {collection === 'send' ? (
            <div className="max-w-[12rem]">
              <label htmlFor="inv-due" className="field-label">
                Due in (days)
              </label>
              <input
                id="inv-due"
                type="number"
                min="1"
                max="90"
                className="field"
                value={dueInDays}
                onChange={(e) => setDueInDays(e.target.value)}
              />
            </div>
          ) : null}
        </fieldset>

        {error ? (
          <p role="alert" className="rounded-md border-2 border-bad bg-[#fdecea] px-3 py-2.5 text-sm font-semibold text-bad">
            {error}
          </p>
        ) : null}

        <button type="submit" className="btn btn-primary w-full" disabled={busy}>
          {busy ? 'Working…' : collection === 'auto' ? 'Issue invoice & charge card' : 'Create & send invoice'}
        </button>
      </form>

      {result ? <ResultPanel invoice={result} /> : null}

      <label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm text-ink-soft">
        <input
          type="checkbox"
          className="size-5 accent-[var(--color-ember-600)]"
          checked={debug}
          onChange={(e) => toggleDebug(e.target.checked)}
        />
        Tracking debug: log whop.track events to this browser’s console
      </label>
    </div>
  )
}

function ResultPanel({ invoice }: { invoice: InvoiceSummary }) {
  const rows: [string, ReactNode][] = [
    ['Invoice id', <code key="id" className="font-mono text-xs">{invoice.id}</code>],
    ['Number', invoice.number],
    ['Status', <span key="s" className="chip capitalize">{invoice.status}</span>],
    ['Subtotal', invoice.subtotal],
    ...(invoice.tax ? ([['Tax', invoice.tax]] as [string, ReactNode][]) : []),
    ['Total', <strong key="t">{invoice.total}</strong>],
    ['Amount due', <strong key="d">{invoice.amountDue}</strong>],
    ...(invoice.email ? ([['Customer email', invoice.email]] as [string, ReactNode][]) : []),
    ...(invoice.dueAt ? ([['Due', new Date(invoice.dueAt).toLocaleDateString('en-US', { dateStyle: 'medium' })]] as [string, ReactNode][]) : []),
  ]
  return (
    <section role="status" aria-label="Invoice result" className="card bg-card p-5 sm:p-7">
      <p className="eyebrow !text-ok">{invoice.collection === 'auto' ? 'Issued & charging' : 'Sent'}</p>
      <h2 className="mt-1 text-4xl text-navy-900 uppercase">Invoice {invoice.number}</h2>
      <dl className="mt-5 divide-y divide-paper-edge text-sm">
        {rows.map(([label, value]) => (
          <div key={label} className="flex items-center justify-between gap-4 py-2.5">
            <dt className="text-ink-soft">{label}</dt>
            <dd className="text-right text-navy-900">{value}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-4 text-sm text-ink-soft">{invoice.note}</p>
      <div className="mt-5 flex flex-col gap-3 sm:flex-row">
        {invoice.checkoutLink ? (
          <a href={invoice.checkoutLink} target="_blank" rel="noreferrer" className="btn btn-navy btn-sm">
            Open payment link
          </a>
        ) : null}
        {invoice.pdfUrl ? (
          <a href={invoice.pdfUrl} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm">
            Download PDF
          </a>
        ) : null}
      </div>
    </section>
  )
}
