import { getPlan, type PlanKey } from '#/site.config'

type TrackProps = Record<string, unknown>

declare global {
  interface Window {
    /** Injected by Whop hosting. Absent in some previews, so always optional. */
    whop?: { track?: (name: string, props?: TrackProps) => void }
  }
}

/**
 * Safe wrapper around window.whop.track. It never throws and does nothing on
 * the server. Set `localStorage.debugTracking = "1"` to also log every event
 * to the browser console with a `[whop.track]` prefix.
 */
export function track(name: string, props: TrackProps = {}): void {
  if (typeof window === 'undefined') return
  try {
    if (window.localStorage.getItem('debugTracking') === '1') {
      // eslint-disable-next-line no-console
      console.log('[whop.track]', name, props)
    }
  } catch {
    /* storage blocked: ignore */
  }
  try {
    window.whop?.track?.(name, props)
  } catch {
    /* tracking must never break the page */
  }
}

/** Fields Whop expects on product events, in major units (dollars). */
export function productProps(key: PlanKey) {
  const plan = getPlan(key)
  return {
    variant_id: plan.id,
    product_id: plan.productId,
    value: plan.price,
    currency: 'USD',
  }
}

/** Attributes that mark an element as showing a Whop product variant. */
export function productAttrs(key: PlanKey) {
  const plan = getPlan(key)
  return {
    'data-whop-product-id': plan.productId,
    'data-whop-variant-id': plan.id,
    'data-whop-price': String(plan.price),
    'data-whop-currency': 'USD',
  } as const
}
