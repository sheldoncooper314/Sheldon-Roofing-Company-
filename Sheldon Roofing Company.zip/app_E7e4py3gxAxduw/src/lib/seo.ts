import { site } from '#/site.config'

interface SeoInput {
  title: string
  description: string
  /** Path such as "/thank-you", used for og:url when a siteUrl is configured. */
  path?: string
  noindex?: boolean
}

/** Meta tags for a route head(): title, description, Open Graph, Twitter. */
export function seo({ title, description, path = '/', noindex }: SeoInput) {
  const url = site.siteUrl ? `${site.siteUrl.replace(/\/$/, '')}${path}` : undefined
  return [
    { title },
    { name: 'description', content: description },
    ...(noindex ? [{ name: 'robots', content: 'noindex, nofollow' }] : []),
    { property: 'og:type', content: 'website' },
    { property: 'og:site_name', content: site.name },
    { property: 'og:title', content: title },
    { property: 'og:description', content: description },
    { property: 'og:image', content: site.heroImageUrl },
    { property: 'og:image:alt', content: site.heroImageAlt },
    ...(url ? [{ property: 'og:url', content: url }] : []),
    { name: 'twitter:card', content: 'summary_large_image' },
    { name: 'twitter:title', content: title },
    { name: 'twitter:description', content: description },
    { name: 'twitter:image', content: site.heroImageUrl },
  ]
}

/** schema.org RoofingContractor built entirely from site.config. */
export function localBusinessJsonLd() {
  const url = site.siteUrl || undefined
  return {
    '@context': 'https://schema.org',
    '@type': 'RoofingContractor',
    name: site.name,
    description: site.seoDescription,
    image: site.heroImageUrl,
    logo: site.logoUrl,
    ...(url ? { url } : {}),
    telephone: site.phone,
    email: site.email,
    address: {
      '@type': 'PostalAddress',
      ...(site.street ? { streetAddress: site.street } : {}),
      addressLocality: site.city,
      addressRegion: site.state,
      ...(site.postalCode ? { postalCode: site.postalCode } : {}),
      addressCountry: 'US',
    },
    areaServed: site.serviceArea.states.map((s) => ({ '@type': 'State', name: s.name })),
    hasOfferCatalog: {
      '@type': 'OfferCatalog',
      name: `${site.shortName} services`,
      itemListElement: [
        ...site.services.map((s) => ({
          '@type': 'Offer',
          itemOffered: { '@type': 'Service', name: s.name, description: s.blurb },
        })),
        {
          '@type': 'Offer',
          price: site.plans.tuneUp.price,
          priceCurrency: 'USD',
          itemOffered: { '@type': 'Service', name: site.plans.tuneUp.title, description: site.plans.tuneUp.description },
        },
      ],
    },
    // Only publish a rating once the reviews are real, never for sample content.
    ...(!site.reviews.isSample
      ? {
          aggregateRating: {
            '@type': 'AggregateRating',
            ratingValue: site.reviews.summary.rating,
            reviewCount: site.reviews.summary.count,
          },
        }
      : {}),
  }
}
