import { site } from '#/site.config'

export interface EstimateInput {
  name: string
  email: string
  phone: string
  address: string
  service: string
  message: string
  referrer?: string
  /** Honeypot. Real visitors never see or fill it. */
  website?: string
}

export type EstimateFieldErrors = Partial<Record<keyof EstimateInput, string>>

export type EstimateResult =
  | { ok: true; leadId: string; service: string }
  | { ok: false; error: string; fieldErrors?: EstimateFieldErrors }

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

/** Used by both the browser and the server so they validate identically. */
export function validateEstimate(input: Partial<EstimateInput>): EstimateFieldErrors {
  const errors: EstimateFieldErrors = {}
  const name = (input.name ?? '').trim()
  const email = (input.email ?? '').trim()
  const phoneDigits = (input.phone ?? '').replace(/\D/g, '')
  const address = (input.address ?? '').trim()
  const message = (input.message ?? '').trim()
  if (name.length < 2) errors.name = 'Enter your name.'
  else if (name.length > 100) errors.name = 'That name is too long.'
  if (!EMAIL_RE.test(email) || email.length > 200) errors.email = 'Enter a valid email address.'
  if (phoneDigits.length < 10 || phoneDigits.length > 15) errors.phone = 'Enter a phone number with area code.'
  if (address.length < 3) errors.address = 'Enter the property address or ZIP code.'
  else if (address.length > 200) errors.address = 'That address is too long.'
  if (!site.estimateForm.serviceOptions.some((o) => o.value === input.service)) {
    errors.service = 'Choose a service.'
  }
  if (message.length > 2000) errors.message = 'Please keep details under 2,000 characters.'
  return errors
}
