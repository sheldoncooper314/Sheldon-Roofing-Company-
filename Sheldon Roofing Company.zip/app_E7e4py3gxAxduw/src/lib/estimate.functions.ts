import { createServerFn } from '@tanstack/react-start'
import { site } from '#/site.config'
import { describeError, whop } from './whop.server'
import { validateEstimate, type EstimateInput, type EstimateResult } from './estimate.shared'

/**
 * A Whop lead must belong to a Whop user, and a first-time website visitor has
 * no Whop account (the API cannot create one from an email alone). So:
 *   1. if the email already belongs to a member of this account, the lead is
 *      recorded against that person;
 *   2. otherwise it is recorded against the account's owner/admin user, and the
 *      visitor's real name, email, phone and address travel in the lead's
 *      metadata so nothing is lost.
 */
async function resolveUserId(email: string): Promise<string> {
  const client = whop()
  const lower = email.toLowerCase()

  try {
    const existing = await client.members.list({ account_id: site.accountId, query: email, first: 5 })
    const match = existing.data.find((m) => m.email?.toLowerCase() === lower)
    if (match?.user?.id) return match.user.id
  } catch (error) {
    // Email lookup needs an extra scope; fall through to the owner.
    console.warn('[estimate] member lookup skipped', describeError(error))
  }

  const admins = await client.members.list({ account_id: site.accountId, access_level: 'admin', first: 1 })
  const owner = admins.data[0]?.user?.id
  if (!owner) throw new Error('This account has no admin member to attach the lead to.')
  return owner
}

export const submitEstimateFn = createServerFn({ method: 'POST' })
  .validator((input: EstimateInput) => {
    if (!input || typeof input !== 'object') throw new Error('Missing form data.')
    const clean: EstimateInput = {
      name: String(input.name ?? ''),
      email: String(input.email ?? ''),
      phone: String(input.phone ?? ''),
      address: String(input.address ?? ''),
      service: String(input.service ?? ''),
      message: String(input.message ?? ''),
      referrer: input.referrer ? String(input.referrer).slice(0, 500) : undefined,
      website: input.website ? String(input.website) : undefined,
    }
    return clean
  })
  .handler(async ({ data }): Promise<EstimateResult> => {
    // Honeypot: pretend it worked, store nothing.
    if (data.website) return { ok: true, leadId: 'lead_ignored', service: data.service }

    const fieldErrors = validateEstimate(data)
    if (Object.keys(fieldErrors).length) {
      return { ok: false, error: 'Please fix the highlighted fields.', fieldErrors }
    }

    const name = data.name.trim()
    const email = data.email.trim()
    let stage = 'resolve user'
    try {
      const userId = await resolveUserId(email)
      stage = 'create lead'
      const referrer = data.referrer && /^https?:\/\//.test(data.referrer) ? data.referrer : undefined
      const lead = await whop().leads.create({
        account_id: site.accountId,
        user_id: userId,
        product_id: site.estimateForm.leadProductByService[data.service] ?? undefined,
        referrer,
        metadata: {
          name,
          email,
          phone: data.phone.trim(),
          address: data.address.trim(),
          service: data.service,
          message: data.message.trim(),
          referrer: referrer ?? '',
          source: 'sheldon-roofing-site',
        },
      })
      return { ok: true, leadId: lead.id, service: data.service }
    } catch (error) {
      console.error(`[estimate] lead creation failed at "${stage}"`, describeError(error))
      return {
        ok: false,
        error: `We could not send your request just now. Please try again, or call ${site.phone}.`,
      }
    }
  })
