import { getCookie, setCookie, deleteCookie } from '@tanstack/react-start/server'
import { getEnv, safeEqual } from './whop.server'

/**
 * Tiny HMAC-signed cookie helper (Web Crypto, works in Workers). Used for the
 * deposit "card on file" hand-off and the admin unlock cookie. No database.
 */

const enc = new TextEncoder()

function b64urlEncode(bytes: Uint8Array): string {
  let s = ''
  for (const b of bytes) s += String.fromCharCode(b)
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

function b64urlDecode(input: string): Uint8Array {
  const pad = input.length % 4 === 0 ? '' : '='.repeat(4 - (input.length % 4))
  const bin = atob(input.replace(/-/g, '+').replace(/_/g, '/') + pad)
  return Uint8Array.from(bin, (c) => c.charCodeAt(0))
}

async function hmac(secret: string, data: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  )
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data))
  return b64urlEncode(new Uint8Array(sig))
}

export async function signPayload(payload: Record<string, unknown>, secret: string, ttlSeconds: number) {
  const body = b64urlEncode(enc.encode(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + ttlSeconds })))
  return `${body}.${await hmac(secret, body)}`
}

export async function verifyPayload<T extends Record<string, unknown>>(
  token: string | undefined,
  secret: string,
): Promise<T | null> {
  if (!token || !secret) return null
  const [body, sig] = token.split('.')
  if (!body || !sig) return null
  if (!safeEqual(sig, await hmac(secret, body))) return null
  try {
    const data = JSON.parse(new TextDecoder().decode(b64urlDecode(body))) as T & { exp?: number }
    if (typeof data.exp !== 'number' || data.exp < Date.now() / 1000) return null
    return data
  } catch {
    return null
  }
}

/** Secret used to sign cookies, or '' when none is configured. */
export function cookieSecret(): string {
  const env = getEnv()
  return env.SESSION_SECRET || env.ADMIN_DEMO_KEY || ''
}

export async function writeSignedCookie(
  name: string,
  payload: Record<string, unknown>,
  ttlSeconds: number,
  secret = cookieSecret(),
): Promise<boolean> {
  if (!secret) return false
  setCookie(name, await signPayload(payload, secret, ttlSeconds), {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: ttlSeconds,
  })
  return true
}

export async function readSignedCookie<T extends Record<string, unknown>>(
  name: string,
  secret = cookieSecret(),
): Promise<T | null> {
  return verifyPayload<T>(getCookie(name), secret)
}

export function clearCookie(name: string) {
  deleteCookie(name, { path: '/' })
}

/** Cookie that remembers the saved deposit card for the demo balance step. */
export const DEPOSIT_COOKIE = 'sr_deposit'
