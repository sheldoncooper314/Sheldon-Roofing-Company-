import { env } from 'cloudflare:workers'
import { WhopClient } from '@whop/sdk'

/**
 * Server-only Whop client. The platform attaches the company API key to
 * requests at the network edge, so no key is ever read or stored here.
 */
export function whop() {
  return new WhopClient({
    token: env.WHOP_API_KEY ?? '',
    baseUrl: `${env.WHOP_API_ORIGIN ?? 'https://api.whop.com'}/api/v1`,
  })
}

export function getEnv() {
  return env
}

/** Turn any SDK or runtime error into a short, safe message for the browser. */
export function describeError(error: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (error && typeof error === 'object') {
    const e = error as { message?: unknown; body?: { error?: { message?: unknown } } }
    const apiMessage = e.body?.error?.message
    if (typeof apiMessage === 'string' && apiMessage) return apiMessage
    if (typeof e.message === 'string' && e.message) {
      // SDK errors are descriptive; keep the first line only.
      return e.message.split('\n')[0]!.slice(0, 300)
    }
  }
  return fallback
}

/** Constant-time string comparison. */
export function safeEqual(a: string, b: string): boolean {
  const enc = new TextEncoder()
  const x = enc.encode(a)
  const y = enc.encode(b)
  let diff = x.length ^ y.length
  const len = Math.max(x.length, y.length)
  for (let i = 0; i < len; i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0)
  return diff === 0
}

/** j•••••@example.com */
export function maskEmail(email: string | null | undefined): string | null {
  if (!email) return null
  const [user, domain] = email.split('@')
  if (!user || !domain) return null
  return `${user.slice(0, 1)}${'•'.repeat(Math.max(2, Math.min(user.length - 1, 6)))}@${domain}`
}
