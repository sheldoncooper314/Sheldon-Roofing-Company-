import { createServerFn } from '@tanstack/react-start'
import { getPlan, site } from '#/site.config'
import { DEPOSIT_COOKIE, clearCookie, readSignedCookie, writeSignedCookie } from './signed.server'
import { describeError, getEnv, maskEmail, safeEqual, whop } from './whop.server'

/** Pinned on every invoice request, as the contractor tool was built against it. */
const INVOICE_API_VERSION = '2026-10-24'
const ADMIN_COOKIE = 'sr_admin'
const ADMIN_TTL = 60 * 60 * 8

/* ── Gate ────────────────────────────────────────────────────────────────── */

async function isUnlocked(): Promise<boolean> {
  const secret = getEnv().ADMIN_DEMO_KEY
  if (!secret) return false
  const cookie = await readSignedCookie<{ a?: string }>(ADMIN_COOKIE, secret)
  return cookie?.a === 'ok'
}

export interface AdminStatus {
  /** ADMIN_DEMO_KEY is set as an app secret. */
  configured: boolean
  unlocked: boolean
  /** A card saved by a deposit made in this browser, if any. */
  browserCard: { emailMasked: string | null; autoChargeConsent: boolean } | null
}

export const adminStatusFn = createServerFn({ method: 'GET' }).handler(async (): Promise<AdminStatus> => {
  const configured = Boolean(getEnv().ADMIN_DEMO_KEY)
  const unlocked = await isUnlocked()
  let browserCard: AdminStatus['browserCard'] = null
  if (unlocked) {
    const saved = await readSignedCookie<{ m?: string | null; pm?: string; e?: string | null; c?: number }>(DEPOSIT_COOKIE)
    if (saved?.m && saved.pm) browserCard = { emailMasked: maskEmail(saved.e), autoChargeConsent: saved.c === 1 }
  }
  return { configured, unlocked, browserCard }
})

export const adminUnlockFn = createServerFn({ method: 'POST' })
  .validator((input: { key: string }) => ({ key: String(input?.key ?? '').slice(0, 500) }))
  .handler(async ({ data }): Promise<{ ok: boolean; error?: string }> => {
    const secret = getEnv().ADMIN_DEMO_KEY
    if (!secret) return { ok: false, error: 'ADMIN_DEMO_KEY is not set. See the README.' }
    if (!data.key || !safeEqual(data.key, secret)) {
      await new Promise((resolve) => setTimeout(resolve, 700))
      return { ok: false, error: 'That key is not right.' }
    }
    await writeSignedCookie(ADMIN_COOKIE, { a: 'ok' }, ADMIN_TTL, secret)
    return { ok: true }
  })

export const adminLockFn = createServerFn({ method: 'POST' }).handler(async () => {
  clearCookie(ADMIN_COOKIE)
  return { ok: true }
})

/* ── Final invoice ───────────────────────────────────────────────────────── */

export interface FinalInvoiceInput {
  /** An email address, or a `mber_…` member id. Ignored when `useBrowserCard` is set. */
  customer: string
  customerName?: string
  jobDescription: string
  /** Contract total before the deposit, optional, only used to print the math. */
  jobTotal?: number
  /** Amount still owed after the deposit, in dollars. */
  balance: number
  collection: 'auto' | 'send'
  dueInDays?: number
  /** Charge the card saved by the deposit made in this browser. */
  useBrowserCard?: boolean
  /** Stable per form attempt, so a double click cannot create two invoices. */
  idempotencyKey: string
}

export interface InvoiceSummary {
  id: string
  number: string
  status: string
  subtotal: string
  tax: string | null
  total: string
  amountDue: string
  checkoutLink: string | null
  pdfUrl: string | null
  memberId: string | null
  email: string | null
  dueAt: string | null
  paidAt: string | null
  collection: 'auto' | 'send'
  note: string
}

export type FinalInvoiceResult = { ok: true; invoice: InvoiceSummary } | { ok: false; error: string }

const usd = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' })

function money(m: { amount: string; currency: string } | null | undefined): string {
  if (!m) return ''
  const n = Number(m.amount)
  return m.currency.toLowerCase() === 'usd' && Number.isFinite(n) ? usd.format(n) : `${m.amount} ${m.currency.toUpperCase()}`
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

export const createFinalInvoiceFn = createServerFn({ method: 'POST' })
  .validator((input: FinalInvoiceInput) => {
    const balance = Math.round(Number(input?.balance) * 100) / 100
    if (!Number.isFinite(balance) || balance <= 0 || balance > 250_000) {
      throw new Error('Enter a final balance between $0.01 and $250,000.')
    }
    const jobDescription = String(input?.jobDescription ?? '').trim()
    if (jobDescription.length < 3) throw new Error('Describe the job.')
    if (input.collection !== 'auto' && input.collection !== 'send') throw new Error('Choose how to bill the balance.')
    const customer = String(input?.customer ?? '').trim()
    if (!input.useBrowserCard && !customer.startsWith('mber_') && !EMAIL_RE.test(customer)) {
      throw new Error('Enter the customer’s email address or member id (mber_…).')
    }
    const jobTotal = input.jobTotal == null || Number.isNaN(Number(input.jobTotal)) ? undefined : Number(input.jobTotal)
    const dueInDays = Math.min(90, Math.max(1, Math.round(Number(input.dueInDays ?? site.finalInvoice.dueInDays))))
    const key = String(input.idempotencyKey ?? '').slice(0, 80)
    if (key.length < 8) throw new Error('Missing request key. Reload the page and try again.')
    return {
      customer,
      customerName: input.customerName ? String(input.customerName).trim().slice(0, 120) : undefined,
      jobDescription: jobDescription.slice(0, 500),
      jobTotal,
      balance,
      collection: input.collection,
      dueInDays,
      useBrowserCard: Boolean(input.useBrowserCard),
      key,
    }
  })
  .handler(async ({ data }): Promise<FinalInvoiceResult> => {
    if (!(await isUnlocked())) return { ok: false, error: 'Locked. Enter the demo key first.' }

    const client = whop()
    const deposit = getPlan('deposit')
    const opts = (suffix: string) => ({ apiVersionDate: INVOICE_API_VERSION, idempotencyKey: `${data.key}:${suffix}` })

    try {
      /* Who is being billed, and (for auto-charge) which saved card. */
      let memberId: string | undefined
      let email: string | undefined
      let paymentMethodId: string | undefined

      if (data.useBrowserCard) {
        const saved = await readSignedCookie<{ m?: string | null; pm?: string; c?: number }>(DEPOSIT_COOKIE)
        if (!saved?.m || !saved.pm) {
          return { ok: false, error: 'No deposit card was saved in this browser. Enter an email or member id instead.' }
        }
        if (data.collection === 'auto' && saved.c !== 1) {
          return {
            ok: false,
            error:
              'This customer did not agree to have the final balance charged to their card. Choose “Send invoice” instead.',
          }
        }
        memberId = saved.m
        paymentMethodId = saved.pm
      } else if (data.customer.startsWith('mber_')) {
        memberId = data.customer
      } else {
        email = data.customer
      }

      if (data.collection === 'auto') {
        if (!memberId && email) {
          const found = await client.members.list({ account_id: site.accountId, query: email, first: 5 })
          memberId = found.data.find((m) => m.email?.toLowerCase() === email!.toLowerCase())?.id
          if (memberId) email = undefined
        }
        if (!memberId) {
          return {
            ok: false,
            error: 'No customer with that email has paid or saved a card yet. Use “Send invoice” instead.',
          }
        }
        if (!paymentMethodId) {
          const methods = await client.paymentMethods.list({ member_id: memberId, future_usage: 'off_session', first: 20 })
          const list = methods.data
          const card = list.find((m) => m.typename === 'CardPaymentMethod') ?? list[0]
          if (!card) {
            return { ok: false, error: 'That customer has no card on file that can be charged. Use “Send invoice” instead.' }
          }
          paymentMethodId = card.id
        }
      }

      const math =
        data.jobTotal && data.jobTotal > data.balance
          ? ` Contract total ${usd.format(data.jobTotal)} less ${usd.format(deposit.price)} deposit already paid = ${usd.format(data.balance)} due.`
          : ` The ${usd.format(deposit.price)} project deposit has already been paid and is not billed again.`
      const memo = `Final balance for: ${data.jobDescription}.${math}`.slice(0, 1000)

      const draft = await client.invoices.create(
        {
          account_id: site.accountId,
          ...(memberId ? { member_id: memberId } : { email_address: email }),
          ...(!memberId && data.customerName ? { customer_name: data.customerName } : {}),
          items: [
            {
              quantity: 1,
              description: memo,
              variant: {
                currency: 'usd',
                billing_type: 'one_time',
                initial_price: data.balance,
                title: 'Final balance',
                visibility: 'hidden',
                force_create_new_plan: true,
                product: {
                  external_identifier: site.finalInvoice.productExternalId,
                  title: site.finalInvoice.productTitle,
                  visibility: 'hidden',
                },
              },
            },
          ],
          memo,
          // With a saved card, a future due date would delay the charge, so none is set.
          ...(data.collection === 'send'
            ? { due_at: new Date(Date.now() + data.dueInDays * 86_400_000).toISOString() }
            : { payment_method_id: paymentMethodId }),
          metadata: {
            source: 'sheldon-roofing-site',
            kind: 'final-balance',
            deposit_product_id: deposit.productId,
            collection: data.collection,
          },
        },
        opts('create'),
      )

      const sent =
        data.collection === 'auto'
          ? await client.invoices.issue({ id: draft.id }, opts('issue'))
          : await client.invoices.send({ id: draft.id }, opts('send'))

      let pdfUrl: string | null = null
      try {
        pdfUrl = (await client.invoices.generatePdf({ id: sent.id, include_descriptions: true }, { apiVersionDate: INVOICE_API_VERSION })).url
      } catch {
        /* the PDF is a convenience */
      }

      return {
        ok: true,
        invoice: {
          id: sent.id,
          number: sent.number,
          status: sent.status,
          subtotal: money(sent.subtotal),
          tax: sent.tax_amount ? money(sent.tax_amount) : null,
          total: money(sent.total),
          amountDue: money(sent.amount_due),
          checkoutLink: sent.checkout_link ?? null,
          pdfUrl,
          memberId: sent.member_id ?? memberId ?? null,
          email: sent.email_address ?? null,
          dueAt: sent.due_at ?? null,
          paidAt: sent.paid_at ?? null,
          collection: data.collection,
          note:
            data.collection === 'auto'
              ? 'The saved card is being charged now. The status updates to paid when the charge settles; if it is declined, the customer is emailed the payment link.'
              : 'The invoice was emailed to the customer with a secure payment link.',
        },
      }
    } catch (error) {
      return { ok: false, error: describeError(error, 'The invoice could not be created.') }
    }
  })
