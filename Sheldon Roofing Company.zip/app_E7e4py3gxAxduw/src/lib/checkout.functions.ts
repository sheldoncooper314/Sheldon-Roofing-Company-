import { createServerFn } from '@tanstack/react-start'
import { getPlan, isPlanKey, site, type PlanKey } from '#/site.config'
import { describeError, maskEmail, safeEqual, whop } from './whop.server'
import { DEPOSIT_COOKIE, readSignedCookie, writeSignedCookie } from './signed.server'

const DEPOSIT_COOKIE_TTL = 60 * 60 * 24 * 30

function requireHttps(url: unknown): string {
  if (typeof url !== 'string') throw new Error('A return URL is required.')
  let parsed: URL
  try {
    parsed = new URL(url)
  } catch {
    throw new Error('The return URL is not valid.')
  }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || url.length > 2000) {
    throw new Error('The return URL must be an https URL.')
  }
  return parsed.toString()
}

function requireToken(value: unknown): string {
  if (typeof value !== 'string' || !value.startsWith('ctok_') || value.length > 300) {
    throw new Error('Payment details were not collected. Please try again.')
  }
  return value
}

export interface PaymentResult {
  ok: true
  id: string
  status: string
  clientSecret: string | null
}
export interface Failure {
  ok: false
  error: string
}

/* ── One-time payment (inspection fee, tune-up, deposit fallback) ───────── */

export const createPaymentFn = createServerFn({ method: 'POST' })
  .validator((input: { confirmationToken: string; plan: PlanKey; returnUrl: string }) => {
    if (!isPlanKey(input?.plan)) throw new Error('Unknown plan.')
    return {
      confirmationToken: requireToken(input.confirmationToken),
      plan: input.plan,
      returnUrl: requireHttps(input.returnUrl),
    }
  })
  .handler(async ({ data }): Promise<PaymentResult | Failure> => {
    const plan = getPlan(data.plan)
    try {
      // The variant is always taken from site.config, never from the browser.
      const payment = await whop().payments.create({
        account_id: site.accountId,
        variant_id: plan.id,
        confirmation_token: data.confirmationToken,
        return_url: data.returnUrl,
        metadata: { source: 'sheldon-roofing-site', plan: data.plan, product_id: plan.productId },
      })
      return { ok: true, id: payment.id, status: payment.status, clientSecret: payment.client_secret ?? null }
    } catch (error) {
      return { ok: false, error: describeError(error, 'The payment could not be created.') }
    }
  })

/* ── Deposit, step 1: save the card with a setup intent ─────────────────── */

export interface SetupResult {
  ok: true
  id: string
  status: string
  clientSecret: string | null
}

export const createSetupIntentFn = createServerFn({ method: 'POST' })
  .validator((input: { confirmationToken: string; returnUrl: string; autoChargeConsent?: boolean }) => ({
    confirmationToken: requireToken(input?.confirmationToken),
    returnUrl: requireHttps(input?.returnUrl),
    autoChargeConsent: input?.autoChargeConsent === true,
  }))
  .handler(async ({ data }): Promise<SetupResult | Failure> => {
    try {
      const setup = await whop().setupIntents.create({
        account_id: site.accountId,
        confirmation_token: data.confirmationToken,
        currency: 'usd',
        return_url: data.returnUrl,
        metadata: {
          source: 'sheldon-roofing-site',
          purpose: 'deposit',
          // Recorded on the setup intent so the final balance is only auto-charged with consent.
          final_balance_auto_charge: data.autoChargeConsent ? 'yes' : 'no',
        },
      })
      return { ok: true, id: setup.id, status: setup.status, clientSecret: setup.client_secret ?? null }
    } catch (error) {
      return { ok: false, error: describeError(error, 'We could not save that card.') }
    }
  })

export interface SavedCard {
  ok: true
  setupIntentId: string
  clientSecret: string
  brand: string | null
  last4: string | null
  emailMasked: string | null
  /** True when the card reference was stored in the signed cookie. */
  remembered: boolean
}

/**
 * Called once the setup intent has succeeded. Re-reads it from Whop (never
 * trusting the browser), then remembers member + payment method in a signed,
 * httpOnly cookie for the demo "final balance" step.
 */
export const finalizeSetupFn = createServerFn({ method: 'POST' })
  .validator((input: { setupIntentId: string; clientSecret: string }) => {
    if (typeof input?.setupIntentId !== 'string' || !input.setupIntentId.startsWith('sint_')) {
      throw new Error('Missing setup reference.')
    }
    if (typeof input.clientSecret !== 'string' || !input.clientSecret) throw new Error('Missing setup secret.')
    return input
  })
  .handler(async ({ data }): Promise<SavedCard | Failure> => {
    try {
      const client = whop()
      const setup = await client.setupIntents.retrieve({ id: data.setupIntentId })
      if (!setup.client_secret || !safeEqual(setup.client_secret, data.clientSecret)) {
        return { ok: false, error: 'That card setup could not be verified.' }
      }
      if (setup.status !== 'succeeded' || !setup.payment_method_id) {
        return { ok: false, error: 'The card was not saved. Please try again.' }
      }

      let memberId = setup.member_id
      if (!memberId && setup.user?.id) {
        const page = await client.members.list({ account_id: site.accountId, user_ids: [setup.user.id], first: 1 })
        memberId = page.data[0]?.id ?? null
      }
      let email: string | null = null
      if (memberId) {
        try {
          email = (await client.members.retrieve({ id: memberId })).email
        } catch {
          /* email is optional */
        }
      }

      const remembered = await writeSignedCookie(
        DEPOSIT_COOKIE,
        {
          m: memberId,
          pm: setup.payment_method_id,
          e: email,
          s: setup.id,
          c: setup.metadata?.final_balance_auto_charge === 'yes' ? 1 : 0,
        },
        DEPOSIT_COOKIE_TTL,
      )
      const card = setup.payment_instrument?.card
      return {
        ok: true,
        setupIntentId: setup.id,
        clientSecret: data.clientSecret,
        brand: card?.brand ?? null,
        last4: card?.last4 ?? null,
        emailMasked: maskEmail(email),
        remembered,
      }
    } catch (error) {
      return { ok: false, error: describeError(error, 'We could not confirm the saved card.') }
    }
  })

/* ── Deposit, step 2: charge the deposit plan to the saved card ─────────── */

export const chargeDepositFn = createServerFn({ method: 'POST' })
  .validator((input: { setupIntentId: string; clientSecret: string; returnUrl: string }) => {
    if (typeof input?.setupIntentId !== 'string' || !input.setupIntentId.startsWith('sint_')) {
      throw new Error('Missing setup reference.')
    }
    if (typeof input.clientSecret !== 'string' || !input.clientSecret) throw new Error('Missing setup secret.')
    return { ...input, returnUrl: requireHttps(input.returnUrl) }
  })
  .handler(async ({ data }): Promise<PaymentResult | Failure> => {
    try {
      const client = whop()
      const setup = await client.setupIntents.retrieve({ id: data.setupIntentId })
      if (!setup.client_secret || !safeEqual(setup.client_secret, data.clientSecret)) {
        return { ok: false, error: 'That card setup could not be verified.' }
      }
      if (setup.status !== 'succeeded' || !setup.payment_method_id) {
        return { ok: false, error: 'The saved card is not ready to charge.' }
      }

      let memberId = setup.member_id
      if (!memberId) {
        const saved = await readSignedCookie<{ m?: string | null; s?: string }>(DEPOSIT_COOKIE)
        if (saved?.s === setup.id && saved.m) memberId = saved.m
      }
      if (!memberId && setup.user?.id) {
        const page = await client.members.list({ account_id: site.accountId, user_ids: [setup.user.id], first: 1 })
        memberId = page.data[0]?.id ?? null
      }
      if (!memberId) return { ok: false, error: 'We could not find the customer for this card.' }

      const deposit = getPlan('deposit')
      const payment = await client.payments.create(
        {
          account_id: site.accountId,
          variant_id: deposit.id,
          member_id: memberId,
          payment_method_id: setup.payment_method_id,
          // The customer is on the page, so a 3D Secure challenge can be shown.
          off_session: false,
          return_url: data.returnUrl,
          metadata: {
            source: 'sheldon-roofing-site',
            plan: 'deposit',
            product_id: deposit.productId,
            setup_intent_id: setup.id,
          },
        },
        // One deposit per saved card setup, even on a double click.
        { idempotencyKey: `deposit-${setup.id}` },
      )
      return { ok: true, id: payment.id, status: payment.status, clientSecret: payment.client_secret ?? null }
    } catch (error) {
      return { ok: false, error: describeError(error, 'The deposit could not be charged to that card.') }
    }
  })
