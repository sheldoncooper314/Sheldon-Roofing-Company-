import { site } from '#/site.config'

export function Faq() {
  return (
    <section id="faq" className="border-t-2 border-navy-900 bg-paper-deep py-16 sm:py-24">
      <div className="wrap grid gap-10 lg:grid-cols-[0.8fr_1.6fr]">
        <div>
          <p className="eyebrow">FAQ</p>
          <h2 className="h-section mt-2">Straight answers.</h2>
          <p className="mt-4 max-w-sm text-ink-soft">
            Something missing? Call{' '}
            <a href={site.phoneHref} className="font-bold text-navy-900 underline underline-offset-4">
              {site.phone}
            </a>{' '}
            or send us a note below.
          </p>
        </div>

        <div className="divide-y-2 divide-navy-900 border-y-2 border-navy-900">
          {site.faq.map((item) => (
            <details key={item.q} className="group">
              <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-4 py-4 font-display text-2xl font-bold tracking-wide text-navy-900 uppercase [&::-webkit-details-marker]:hidden">
                {item.q}
                <span
                  aria-hidden="true"
                  className="grid size-9 shrink-0 place-items-center rounded-full border-2 border-navy-900 text-xl leading-none transition-transform group-open:rotate-45 group-open:bg-ember-500 group-open:text-white"
                >
                  +
                </span>
              </summary>
              <p className="max-w-2xl pb-5 text-ink-soft">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}
