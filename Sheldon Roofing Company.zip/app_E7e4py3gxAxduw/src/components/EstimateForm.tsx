import { useEffect, useState, type FormEvent } from 'react'
import { site } from '#/site.config'
import { track } from '#/lib/track'
import { submitEstimateFn } from '#/lib/estimate.functions'
import { validateEstimate, type EstimateFieldErrors, type EstimateInput } from '#/lib/estimate.shared'
import { CheckIcon, MailIcon, PhoneIcon } from './Icons'

const EMPTY: EstimateInput = { name: '', email: '', phone: '', address: '', service: '', message: '', website: '' }

export function EstimateForm() {
  const [values, setValues] = useState<EstimateInput>(EMPTY)
  const [errors, setErrors] = useState<EstimateFieldErrors>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState<{ leadId: string; service: string; name: string } | null>(null)

  // "Request an estimate" buttons on service cards preselect their service.
  useEffect(() => {
    const onPrefill = (event: Event) => {
      const service = (event as CustomEvent<{ service?: string }>).detail?.service
      if (service && site.estimateForm.serviceOptions.some((o) => o.value === service)) {
        setValues((v) => ({ ...v, service }))
      }
    }
    window.addEventListener('estimate:prefill', onPrefill)
    return () => window.removeEventListener('estimate:prefill', onPrefill)
  }, [])

  const set = (key: keyof EstimateInput) => (event: { target: { value: string } }) => {
    setValues((v) => ({ ...v, [key]: event.target.value }))
    if (errors[key]) setErrors((e) => ({ ...e, [key]: undefined }))
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    if (busy) return
    setFormError(null)
    const found = validateEstimate(values)
    if (Object.keys(found).length) {
      setErrors(found)
      setFormError('Please fix the highlighted fields.')
      document.getElementById(`est-${Object.keys(found)[0]}`)?.focus()
      return
    }
    setBusy(true)
    try {
      const result = await submitEstimateFn({
        data: { ...values, referrer: document.referrer || window.location.href },
      })
      if (!result.ok) {
        if (result.fieldErrors) setErrors(result.fieldErrors)
        setFormError(result.error)
        return
      }
      track('estimate_requested', { service: result.service, event_id: result.leadId })
      track('lead', { service: result.service, event_id: result.leadId })
      setDone({ leadId: result.leadId, service: result.service, name: values.name.trim().split(' ')[0] ?? '' })
      setValues(EMPTY)
    } catch {
      setFormError(`We could not send your request just now. Please try again, or call ${site.phone}.`)
    } finally {
      setBusy(false)
    }
  }

  const invalid = (key: keyof EstimateInput) => (errors[key] ? { 'aria-invalid': true, 'aria-describedby': `est-${key}-error` } : {})
  const fieldError = (key: keyof EstimateInput) =>
    errors[key] ? (
      <p id={`est-${key}-error`} className="field-error">
        {errors[key]}
      </p>
    ) : null

  return (
    <section id="estimate" className="bg-shingles py-16 text-white sm:py-24">
      <div className="wrap grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div>
          <p className="eyebrow !text-ember-400">Request an estimate</p>
          <h2 className="mt-2 text-[clamp(2.6rem,6vw,4.5rem)] text-white uppercase">{site.estimateForm.heading}</h2>
          <p className="mt-4 max-w-md text-white/75">{site.estimateForm.sub}</p>
          <ul className="mt-8 space-y-3 text-white/90">
            <li>
              <a href={site.phoneHref} className="inline-flex min-h-11 items-center gap-3 font-display text-3xl font-bold tracking-wide hover:text-ember-400">
                <PhoneIcon className="size-6 text-ember-400" /> {site.phone}
              </a>
            </li>
            <li>
              <a href={`mailto:${site.email}`} className="inline-flex min-h-11 items-center gap-3 hover:text-ember-400">
                <MailIcon className="size-5 text-ember-400" /> {site.email}
              </a>
            </li>
          </ul>
          <p className="mt-6 text-sm text-white/60">{site.hours}</p>
        </div>

        <div className="rounded-md border-2 border-white bg-paper p-5 text-ink shadow-[7px_7px_0_var(--color-ember-500)] sm:p-8">
          {done ? (
            <div role="status" className="py-6 text-center">
              <span className="mx-auto grid size-16 place-items-center rounded-full bg-ok text-white">
                <CheckIcon className="size-8" />
              </span>
              <h3 className="mt-5 text-4xl text-navy-900 uppercase">Request received{done.name ? `, ${done.name}` : ''}.</h3>
              <p className="mx-auto mt-3 max-w-sm text-ink-soft">
                Thanks. We will reach out within one business day to set up your estimate.
              </p>
              <p className="mt-5 inline-block rounded-md bg-paper-deep px-3 py-2 text-xs font-semibold text-ink-soft">
                Reference: <span className="font-mono text-navy-900">{done.leadId}</span>
              </p>
              <div className="mt-6">
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setDone(null)}>
                  Send another request
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-5">
              {formError ? (
                <p role="alert" className="rounded-md border-2 border-bad bg-[#fdecea] px-3 py-2.5 text-sm font-semibold text-bad">
                  {formError}
                </p>
              ) : null}

              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label htmlFor="est-name" className="field-label">
                    Name
                  </label>
                  <input id="est-name" className="field" autoComplete="name" value={values.name} onChange={set('name')} {...invalid('name')} />
                  {fieldError('name')}
                </div>
                <div>
                  <label htmlFor="est-phone" className="field-label">
                    Phone
                  </label>
                  <input
                    id="est-phone"
                    type="tel"
                    inputMode="tel"
                    className="field"
                    autoComplete="tel"
                    placeholder="(555) 555-5555"
                    value={values.phone}
                    onChange={set('phone')}
                    {...invalid('phone')}
                  />
                  {fieldError('phone')}
                </div>
              </div>

              <div>
                <label htmlFor="est-email" className="field-label">
                  Email
                </label>
                <input
                  id="est-email"
                  type="email"
                  inputMode="email"
                  className="field"
                  autoComplete="email"
                  value={values.email}
                  onChange={set('email')}
                  {...invalid('email')}
                />
                {fieldError('email')}
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label htmlFor="est-address" className="field-label">
                    Property address or ZIP
                  </label>
                  <input
                    id="est-address"
                    className="field"
                    autoComplete="street-address"
                    value={values.address}
                    onChange={set('address')}
                    {...invalid('address')}
                  />
                  {fieldError('address')}
                </div>
                <div>
                  <label htmlFor="est-service" className="field-label">
                    Service
                  </label>
                  <select id="est-service" className="field" value={values.service} onChange={set('service')} {...invalid('service')}>
                    <option value="" disabled>
                      Choose a service
                    </option>
                    {site.estimateForm.serviceOptions.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                  {fieldError('service')}
                </div>
              </div>

              <div>
                <label htmlFor="est-message" className="field-label">
                  Project details <span className="font-medium text-ink-soft">(optional)</span>
                </label>
                <textarea
                  id="est-message"
                  className="field"
                  placeholder="Leaks, storm damage, roof age, anything we should know."
                  value={values.message}
                  onChange={set('message')}
                  {...invalid('message')}
                />
                {fieldError('message')}
              </div>

              {/* Honeypot: hidden from people, tempting to bots. */}
              <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                <label htmlFor="est-website">Leave this field empty</label>
                <input
                  id="est-website"
                  name="website"
                  tabIndex={-1}
                  autoComplete="off"
                  value={values.website ?? ''}
                  onChange={set('website')}
                />
              </div>

              <button type="submit" className="btn btn-primary w-full" disabled={busy}>
                {busy ? 'Sending…' : 'Send my request'}
              </button>
              <p className="text-center text-xs text-ink-soft">We only use your details to answer this request.</p>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}
