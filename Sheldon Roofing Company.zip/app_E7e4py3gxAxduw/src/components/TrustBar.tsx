import { site } from '#/site.config'
import { BadgeIcon, DocIcon, ShieldIcon } from './Icons'

const ICONS = [BadgeIcon, ShieldIcon, BadgeIcon, DocIcon]

export function TrustBar() {
  return (
    <section aria-label="Why homeowners trust us" className="bg-shingles text-white">
      <ul className="wrap grid gap-px py-0 sm:grid-cols-2 lg:grid-cols-4">
        {site.trustBadges.map((badge, i) => {
          const Icon = ICONS[i % ICONS.length]!
          return (
            <li key={badge.title} className="flex items-center gap-4 px-1 py-5 lg:px-5 lg:first:pl-0">
              <span className="grid size-12 shrink-0 place-items-center rounded-full border-2 border-ember-500 text-ember-400">
                <Icon className="size-6" />
              </span>
              <div>
                <p className="font-display text-2xl font-bold tracking-wide uppercase">{badge.title}</p>
                <p className="text-sm text-white/70">{badge.text}</p>
              </div>
            </li>
          )
        })}
      </ul>
    </section>
  )
}
