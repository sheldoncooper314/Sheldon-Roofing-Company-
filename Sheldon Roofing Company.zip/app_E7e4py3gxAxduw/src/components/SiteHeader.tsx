import { site } from '#/site.config'
import { PhoneIcon } from './Icons'

export function LogoMark({ size = 44 }: { size?: number }) {
  // The logo file has generous padding, so it is cropped inside a round badge.
  return (
    <span
      className="relative inline-block shrink-0 overflow-hidden rounded-full border-2 border-navy-900 bg-[#fffcf3]"
      style={{ width: size, height: size }}
    >
      <img
        src={site.logoUrl}
        alt=""
        width={size}
        height={size}
        className="absolute inset-0 size-full max-w-none scale-[1.85] object-cover"
      />
    </span>
  )
}

const NAV = [
  { href: '/#services', label: 'Services' },
  { href: '/#how-it-works', label: 'How it works' },
  { href: '/#service-area', label: 'Service area' },
  { href: '/#reviews', label: 'Reviews' },
  { href: '/#faq', label: 'FAQ' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b-2 border-navy-900 bg-paper/95 backdrop-blur supports-[backdrop-filter]:bg-paper/85">
      <div className="hidden bg-navy-900 text-[0.8rem] text-white/85 md:block">
        <div className="wrap flex items-center justify-between gap-6 py-1.5">
          <p className="truncate">{site.emergencyLine}</p>
          <p className="shrink-0 text-white/65">{site.hours}</p>
        </div>
      </div>

      <div className="wrap flex h-16 items-center justify-between gap-2 md:h-[4.5rem] md:gap-3">
        <a href="/" className="flex min-w-0 items-center gap-2.5" aria-label={`${site.name} home`}>
          <LogoMark />
          <span className="min-w-0 leading-none">
            <span className="block font-display text-[1.1rem] leading-[1.05] font-extrabold tracking-wide text-navy-900 uppercase min-[420px]:text-[1.35rem] md:text-[1.6rem]">
              {site.shortName}
            </span>
            <span className="mt-0.5 hidden text-[0.7rem] font-bold tracking-[0.2em] text-ember-600 uppercase sm:block">
              Roofing company
            </span>
          </span>
        </a>

        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="inline-flex min-h-11 items-center rounded-md px-3 text-sm font-bold text-navy-900 hover:bg-paper-deep"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex shrink-0 items-center gap-2">
          <a
            href={site.phoneHref}
            className="inline-flex min-h-11 items-center gap-2 rounded-md px-2 font-display text-xl font-bold tracking-wide text-navy-900 hover:bg-paper-deep sm:px-3"
            aria-label={`Call ${site.phone}`}
          >
            <PhoneIcon className="size-5 text-ember-600" />
            <span className="hidden sm:inline">{site.phone}</span>
          </a>
          <a href="/#estimate" className="btn btn-primary btn-sm">
            <span className="sm:hidden">Estimate</span>
            <span className="hidden sm:inline">Request an Estimate</span>
          </a>
        </div>
      </div>
    </header>
  )
}
