import { site } from '#/site.config'
import { ArrowIcon, PinIcon } from './Icons'

export function ServiceArea() {
  const { states, intro } = site.serviceArea
  return (
    <section id="service-area" className="bg-shingles py-16 text-white sm:py-24">
      <div className="wrap">
        <div className="grid gap-8 lg:grid-cols-[1fr_1.4fr] lg:items-end">
          <div>
            <p className="eyebrow !text-ember-400">Service area</p>
            <h2 className="mt-2 text-[clamp(2.5rem,6vw,4.25rem)] text-white uppercase">
              Local crews in {states.length} states
            </h2>
          </div>
          <div>
            <p className="max-w-xl text-white/75">{intro}</p>
            <a href="#estimate" className="btn btn-ghost-light btn-sm mt-5">
              Check my ZIP code <ArrowIcon className="size-4" />
            </a>
          </div>
        </div>

        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {states.map((state) => (
            <li
              key={state.abbr}
              className="relative overflow-hidden rounded-md border-2 border-white/25 bg-navy-950/45 p-5 transition-colors hover:border-ember-500"
            >
              <span
                aria-hidden="true"
                className="pointer-events-none absolute -top-3 -right-1 font-display text-[7rem] leading-none font-extrabold text-transparent select-none"
                style={{ WebkitTextStroke: '2px rgb(255 255 255 / 0.16)' }}
              >
                {state.abbr}
              </span>
              <h3 className="relative text-4xl text-white uppercase">{state.name}</h3>
              <ul className="relative mt-4 flex flex-wrap gap-2">
                {state.cities.map((city) => (
                  <li
                    key={city}
                    className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/5 px-2.5 py-1 text-sm text-white/90"
                  >
                    <PinIcon className="size-3.5 text-ember-400" /> {city}
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
