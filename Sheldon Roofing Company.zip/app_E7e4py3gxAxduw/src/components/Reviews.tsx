import { site, type ReviewConfig } from '#/site.config'
import { BadgeIcon, DocIcon, ShieldIcon, StarIcon } from './Icons'

function Stars({ rating, className = 'size-5' }: { rating: number; className?: string }) {
  return (
    <span className="inline-flex gap-0.5 text-ember-500" role="img" aria-label={`${rating} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <StarIcon key={n} filled={n <= Math.round(rating)} className={className} />
      ))}
    </span>
  )
}

const BADGE_ICONS = [BadgeIcon, ShieldIcon, BadgeIcon, DocIcon]

export function Reviews() {
  const { summary, items, isSample, sampleNote } = site.reviews
  return (
    <section id="reviews" className="py-16 sm:py-24">
      <div className="wrap">
        <p className="eyebrow">Reviews &amp; credentials</p>
        <h2 className="h-section mt-2 max-w-3xl">Neighbors say it better.</h2>

        <div className="mt-10 grid gap-8 lg:grid-cols-[0.8fr_2fr]">
          <div className="card h-fit bg-navy-900 p-6 text-white !shadow-[5px_5px_0_var(--color-ember-500)]">
            <p className="font-display text-8xl leading-none font-extrabold">{summary.rating.toFixed(1)}</p>
            <div className="mt-3">
              <Stars rating={summary.rating} className="size-6" />
            </div>
            <p className="mt-2 text-sm text-white/75">Average from {summary.count} customer reviews</p>
            {isSample ? (
              <p className="mt-4 rounded bg-white/10 px-3 py-2 text-xs text-white/80">{sampleNote}</p>
            ) : null}
            <ul className="mt-6 space-y-3 border-t border-white/20 pt-5">
              {site.trustBadges.slice(0, 3).map((badge, i) => {
                const Icon = BADGE_ICONS[i % BADGE_ICONS.length]!
                return (
                  <li key={badge.title} className="flex items-center gap-3">
                    <Icon className="size-5 shrink-0 text-ember-400" />
                    <span className="text-sm">
                      <strong className="font-bold text-white">{badge.title}.</strong>{' '}
                      <span className="text-white/70">{badge.text}</span>
                    </span>
                  </li>
                )
              })}
            </ul>
          </div>

          <ul className="grid gap-5 sm:grid-cols-2">
            {(items as ReviewConfig[]).map((review) => (
              <li key={review.name} className="card flex flex-col p-6">
                <Stars rating={review.rating} />
                <blockquote className="mt-3 flex-1 text-[0.97rem] leading-relaxed text-ink">“{review.text}”</blockquote>
                <div className="mt-5 flex items-center justify-between gap-3 border-t border-paper-edge pt-4">
                  <span>
                    <span className="block font-bold text-navy-900">{review.name}</span>
                    <span className="block text-xs text-ink-soft">{review.town}</span>
                  </span>
                  <span className="chip">{review.service}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
