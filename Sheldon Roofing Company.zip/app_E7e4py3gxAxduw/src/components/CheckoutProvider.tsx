import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import type { PlanKey } from '#/site.config'
import { CheckoutModal } from './CheckoutModal'

interface CheckoutContextValue {
  openCheckout: (plan: PlanKey) => void
}

const CheckoutContext = createContext<CheckoutContextValue>({ openCheckout: () => {} })

/** Any button anywhere can call `useCheckout().openCheckout('inspection')`. */
export function useCheckout() {
  return useContext(CheckoutContext)
}

export function CheckoutProvider({ children }: { children: ReactNode }) {
  const [active, setActive] = useState<PlanKey | null>(null)
  const openCheckout = useCallback((plan: PlanKey) => setActive(plan), [])
  const close = useCallback(() => setActive(null), [])
  const value = useMemo(() => ({ openCheckout }), [openCheckout])

  return (
    <CheckoutContext.Provider value={value}>
      {children}
      {active ? <CheckoutModal plan={active} open onClose={close} /> : null}
    </CheckoutContext.Provider>
  )
}
