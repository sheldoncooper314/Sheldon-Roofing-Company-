import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { useNavigate } from '@tanstack/react-router'
import {
  BrandingElement,
  Checkout,
  EmailElement,
  ExpressCheckoutElement,
  PaymentElement,
  Payments,
  WhopElements,
  usePayments,
  useWhop,
} from '@whop/elements-react'
import { loadWhop } from '@whop/elements'
import { formatUsd, getPlan, site, type PlanKey } from '#/site.config'
import { productAttrs, productProps, track } from '#/lib/track'
import {
  chargeDepositFn,
  createPaymentFn,
  createSetupIntentFn,
  finalizeSetupFn,
  type SavedCard,
} from '#/lib/checkout.functions'
import { CloseIcon, LockIcon } from './Icons'

/* ────────────────────────────────────────────────────────────────────────────
   Shared plumbing
   ──────────────────────────────────────────────────────────────────────── */

let elementsLoader: ReturnType<typeof loadWhop> | null = null
/** Load the Whop Elements script once, on the client, when a checkout first opens. */
export function getElements() {
  return (elementsLoader ??= loadWhop())
}

export const elementsAppearance = {
  theme: { appearance: 'light', accentColor: 'orange', grayColor: 'sand' },
} as const

type FinishStatus = 'succeeded' | 'processing'
type Finish = (status: FinishStatus, paymentId?: string) => void

interface Notice {
  tone: 'error' | 'info'
  text: string
}

function isCancelled(error: unknown) {
  return (error as { code?: string } | null)?.code === 'payment_request_cancelled'
}

function errorText(error: unknown, fallback: string) {
  const message = (error as { message?: unknown } | null)?.message
  return typeof message === 'string' && message ? message : fallback
}

function NoticeLine({ notice }: { notice: Notice | null }) {
  if (!notice) return null
  const isError = notice.tone === 'error'
  return (
    <p
      role={isError ? 'alert' : 'status'}
      className={`rounded-md border-2 px-3 py-2.5 text-sm font-semibold ${
        isError
          ? 'border-bad bg-[#fdecea] text-bad'
          : 'border-navy-300 bg-navy-100 text-navy-900'
      }`}
    >
      {notice.text}
    </p>
  )
}

function Spinner() {
  return (
    <span
      aria-hidden="true"
      className="inline-block size-4 animate-spin rounded-full border-2 border-white/40 border-t-white"
    />
  )
}

/** Resolve whatever `handleNextAction` reports into a finish or a message. */
function useNextAction() {
  const whop = useWhop()
  return useCallback(
    async (clientSecret: string, returnUrl: string) => {
      if (!whop) throw new Error('Checkout is still loading. Please try again.')
      return whop.payments.handleNextAction({ clientSecret, returnUrl })
    },
    [whop],
  )
}

/* ────────────────────────────────────────────────────────────────────────────
   Card + wallet form (Payments handle: Email + Payment + Branding)
   ──────────────────────────────────────────────────────────────────────── */

function PayForm({
  planKey,
  returnUrl,
  onFinish,
  label,
}: {
  planKey: PlanKey
  returnUrl: string
  onFinish: Finish
  label?: string
}) {
  const payments = usePayments()
  const nextAction = useNextAction()
  const plan = getPlan(planKey)
  const [complete, setComplete] = useState(false)
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<Notice | null>(null)

  async function pay() {
    if (!payments || busy) return
    setBusy(true)
    setNotice(null)
    try {
      let confirmationToken: string
      try {
        confirmationToken = (await payments.createConfirmationToken({})).confirmationToken
      } catch (error) {
        // The buyer closed a wallet or bank sheet: a cancel, not a failure.
        if (isCancelled(error)) {
          setNotice({ tone: 'info', text: 'Payment cancelled. You have not been charged.' })
        } else {
          setNotice({ tone: 'error', text: errorText(error, 'Check your details and try again.') })
        }
        return
      }

      const created = await createPaymentFn({ data: { confirmationToken, plan: planKey, returnUrl } })
      if (!created.ok) {
        setNotice({ tone: 'error', text: created.error })
        return
      }
      if (created.status === 'paid') {
        onFinish('succeeded', created.id)
        return
      }
      if (!created.clientSecret) {
        onFinish('processing', created.id)
        return
      }

      const result = await nextAction(created.clientSecret, returnUrl)
      if (result.redirected) return
      if (result.status === 'succeeded') onFinish('succeeded', created.id)
      else if (result.status === 'processing') onFinish('processing', created.id)
      else {
        setNotice({
          tone: 'error',
          text: result.lastPaymentError?.message ?? 'The payment was not completed. You have not been charged.',
        })
      }
    } catch (error) {
      setNotice({ tone: 'error', text: errorText(error, 'Something went wrong. You have not been charged.') })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <EmailElement />
      <PaymentElement onChange={(event) => setComplete(event.complete)} />
      {/* Whop's merchant-of-record notice. Required by Payments. */}
      <BrandingElement />
      <NoticeLine notice={notice} />
      <button type="button" className="btn btn-primary w-full" disabled={!complete || busy || !payments} onClick={pay}>
        {busy ? (
          <>
            <Spinner /> Processing…
          </>
        ) : (
          (label ?? `Pay ${formatUsd(plan.price)}`)
        )}
      </button>
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────────────
   Express checkout (Apple Pay / Google Pay) in its own Checkout handle
   ──────────────────────────────────────────────────────────────────────── */

function ExpressSection({ planKey, returnUrl }: { planKey: PlanKey; returnUrl: string }) {
  const plan = getPlan(planKey)
  const [notice, setNotice] = useState<Notice | null>(null)
  return (
    <section aria-label="Express checkout" className="space-y-3">
      {/* CheckoutElement and ExpressCheckoutElement cannot share one handle,
          so the full card form below lives in its own Payments handle. */}
      <Checkout
        plan={plan.id}
        returnUrl={returnUrl}
        metadata={{ source: 'sheldon-roofing-site', plan: planKey, product_id: plan.productId }}
      >
        <ExpressCheckoutElement
          onError={(error) => {
            if (error.code === 'payment_request_cancelled') {
              setNotice({ tone: 'info', text: 'Payment cancelled. You have not been charged.' })
            } else {
              setNotice({ tone: 'error', text: error.message || 'Express checkout is unavailable. Use the card form below.' })
            }
          }}
        />
      </Checkout>
      <NoticeLine notice={notice} />
    </section>
  )
}

function Divider({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-3 text-xs font-extrabold tracking-[0.14em] text-ink-soft uppercase">
      <span className="h-px flex-1 bg-paper-edge" />
      {children}
      <span className="h-px flex-1 bg-paper-edge" />
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────────────
   Deposit: save card with a setup intent, then charge the deposit plan to it
   ──────────────────────────────────────────────────────────────────────── */

function SaveCardForm({ returnUrl, onSaved }: { returnUrl: string; onSaved: (card: SavedCard) => void }) {
  const payments = usePayments()
  const nextAction = useNextAction()
  const [complete, setComplete] = useState(false)
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<Notice | null>(null)
  const [consent, setConsent] = useState(false)

  async function save() {
    if (!payments || busy) return
    setBusy(true)
    setNotice(null)
    try {
      let confirmationToken: string
      try {
        confirmationToken = (await payments.createConfirmationToken({})).confirmationToken
      } catch (error) {
        setNotice(
          isCancelled(error)
            ? { tone: 'info', text: 'Cancelled. Nothing was saved or charged.' }
            : { tone: 'error', text: errorText(error, 'Check your details and try again.') },
        )
        return
      }

      const setup = await createSetupIntentFn({ data: { confirmationToken, returnUrl, autoChargeConsent: consent } })
      if (!setup.ok) {
        setNotice({ tone: 'error', text: setup.error })
        return
      }
      let status = setup.status
      if (status === 'requires_action') {
        if (!setup.clientSecret) throw new Error('This card needs verification but could not be verified.')
        const result = await nextAction(setup.clientSecret, returnUrl)
        if (result.redirected) return
        status = result.status
        if (status !== 'succeeded' && status !== 'processing') {
          setNotice({
            tone: 'error',
            text: result.lastPaymentError?.message ?? 'The card was not verified. Try again or use another card.',
          })
          return
        }
      }
      if (status === 'processing') {
        setNotice({ tone: 'info', text: 'Your bank is still verifying this card. Wait a moment, then press the button again.' })
        return
      }
      if (status !== 'succeeded' || !setup.clientSecret) {
        setNotice({ tone: 'error', text: 'The card could not be saved. Try another card.' })
        return
      }

      const saved = await finalizeSetupFn({ data: { setupIntentId: setup.id, clientSecret: setup.clientSecret } })
      if (!saved.ok) {
        setNotice({ tone: 'error', text: saved.error })
        return
      }
      onSaved(saved)
    } catch (error) {
      setNotice({ tone: 'error', text: errorText(error, 'Something went wrong. Nothing was charged.') })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <EmailElement />
      <PaymentElement onChange={(event) => setComplete(event.complete)} />
      <BrandingElement />
      <p className="text-sm text-ink-soft">
        Step 1 of 2. We save your card securely with Whop. <strong className="text-navy-900">Nothing is charged yet.</strong> Next
        you confirm the {formatUsd(getPlan('deposit').price)} deposit.
      </p>
      <label className="flex min-h-11 cursor-pointer items-start gap-3 rounded-md border-2 border-paper-edge bg-white p-3 text-sm">
        <input
          type="checkbox"
          checked={consent}
          onChange={(event) => setConsent(event.target.checked)}
          className="mt-0.5 size-5 shrink-0 accent-[var(--color-ember-600)]"
        />
        <span className="text-ink-soft">
          <strong className="text-navy-900">Optional:</strong> keep this card on file so {site.shortName} can charge my final
          balance to it after the job is finished and I have approved it. I can still choose to pay the invoice link instead.
        </span>
      </label>
      <NoticeLine notice={notice} />
      <button type="button" className="btn btn-primary w-full" disabled={!complete || busy || !payments} onClick={save}>
        {busy ? (
          <>
            <Spinner /> Saving card…
          </>
        ) : (
          'Save card & continue'
        )}
      </button>
    </div>
  )
}

/**
 * Step 2 of the deposit: charge the deposit plan to the card just saved.
 * Also used by /thank-you when a card save finished after an off-site redirect.
 */
export function DepositChargeStep({
  setupIntentId,
  clientSecret,
  card,
  returnUrl,
  onFinish,
  onUseAnotherCard,
}: {
  setupIntentId: string
  clientSecret: string
  card?: { brand: string | null; last4: string | null; emailMasked?: string | null } | null
  returnUrl: string
  onFinish: Finish
  onUseAnotherCard?: () => void
}) {
  const nextAction = useNextAction()
  const deposit = getPlan('deposit')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<Notice | null>(null)
  const [failed, setFailed] = useState(false)

  async function charge() {
    if (busy) return
    setBusy(true)
    setNotice(null)
    setFailed(false)
    try {
      const res = await chargeDepositFn({ data: { setupIntentId, clientSecret, returnUrl } })
      if (!res.ok) {
        setNotice({ tone: 'error', text: res.error })
        setFailed(true)
        return
      }
      if (res.status === 'paid') {
        onFinish('succeeded', res.id)
        return
      }
      if (!res.clientSecret) {
        onFinish('processing', res.id)
        return
      }
      const result = await nextAction(res.clientSecret, returnUrl)
      if (result.redirected) return
      if (result.status === 'succeeded') onFinish('succeeded', res.id)
      else if (result.status === 'processing') onFinish('processing', res.id)
      else {
        setNotice({
          tone: 'error',
          text: result.lastPaymentError?.message ?? 'The deposit was not completed. You have not been charged.',
        })
        setFailed(true)
      }
    } catch (error) {
      setNotice({ tone: 'error', text: errorText(error, 'Something went wrong. You have not been charged.') })
      setFailed(true)
    } finally {
      setBusy(false)
    }
  }

  const cardLabel = card?.last4 ? `${card.brand ? `${card.brand} ` : 'Card '}ending ${card.last4}` : 'your saved card'

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 rounded-md border-2 border-ok/40 bg-[#eaf6ef] px-3 py-3">
        <span aria-hidden="true" className="grid size-8 shrink-0 place-items-center rounded-full bg-ok text-white">
          ✓
        </span>
        <div className="text-sm">
          <p className="font-extrabold text-navy-900">Card saved</p>
          <p className="text-ink-soft capitalize">{cardLabel}</p>
        </div>
      </div>

      <dl className="divide-y divide-paper-edge rounded-md border-2 border-navy-900 bg-white text-sm">
        <div className="flex justify-between gap-4 px-4 py-3">
          <dt className="font-semibold text-ink-soft">{deposit.title}</dt>
          <dd className="font-extrabold text-navy-900">{formatUsd(deposit.price, { cents: true })}</dd>
        </div>
        <div className="px-4 py-3 text-ink-soft">
          Step 2 of 2. Credited in full on your final invoice, so you only pay the remaining balance after the job.
        </div>
      </dl>

      <NoticeLine notice={notice} />
      <button type="button" className="btn btn-primary w-full" disabled={busy} onClick={charge}>
        {busy ? (
          <>
            <Spinner /> Charging deposit…
          </>
        ) : failed ? (
          `Try again — pay ${formatUsd(deposit.price)}`
        ) : (
          `Pay ${formatUsd(deposit.price)} deposit`
        )}
      </button>
      {failed && onUseAnotherCard ? (
        <button type="button" className="btn btn-ghost btn-sm w-full" onClick={onUseAnotherCard}>
          Pay with a different card instead
        </button>
      ) : null}
    </div>
  )
}

function DepositFlow({ returnUrl, onFinish }: { returnUrl: string; onFinish: Finish }) {
  const deposit = getPlan('deposit')
  const [step, setStep] = useState<'save' | 'charge' | 'fallback'>('save')
  const [saved, setSaved] = useState<SavedCard | null>(null)

  if (step === 'charge' && saved) {
    return (
      <WhopElements elements={getElements()} appearance={elementsAppearance}>
        <DepositChargeStep
          setupIntentId={saved.setupIntentId}
          clientSecret={saved.clientSecret}
          card={saved}
          returnUrl={returnUrl}
          onFinish={onFinish}
          onUseAnotherCard={() => setStep('fallback')}
        />
      </WhopElements>
    )
  }

  if (step === 'fallback') {
    return (
      <WhopElements elements={getElements()} appearance={elementsAppearance}>
        <div className="space-y-4">
          <p className="text-sm text-ink-soft">
            Pay the {formatUsd(deposit.price)} deposit with a different card. We will keep it on file for your final balance.
          </p>
          {/* Fallback: the standard payment form, saving the card for later use. */}
          <Payments accountId={site.accountId} plan={deposit.id} returnUrl={returnUrl} setupFutureUsage="off_session">
            <PayForm planKey="deposit" returnUrl={returnUrl} onFinish={onFinish} />
          </Payments>
        </div>
      </WhopElements>
    )
  }

  return (
    <WhopElements elements={getElements()} appearance={elementsAppearance}>
      <Payments accountId={site.accountId} mode="setup" currency="usd" returnUrl={returnUrl}>
        <SaveCardForm
          returnUrl={returnUrl}
          onSaved={(card) => {
            setSaved(card)
            setStep('charge')
          }}
        />
      </Payments>
    </WhopElements>
  )
}

/* ────────────────────────────────────────────────────────────────────────────
   The modal
   ──────────────────────────────────────────────────────────────────────── */

export function CheckoutModal({ plan: planKey, open, onClose }: { plan: PlanKey; open: boolean; onClose: () => void }) {
  if (!open) return null
  return <OpenCheckout key={planKey} planKey={planKey} onClose={onClose} />
}

function OpenCheckout({ planKey, onClose }: { planKey: PlanKey; onClose: () => void }) {
  const plan = getPlan(planKey)
  const navigate = useNavigate()
  const dialogRef = useRef<HTMLDialogElement>(null)
  const [returnUrl] = useState(() => `${window.location.origin}/thank-you?plan=${planKey}`)

  // Open as a native modal dialog: focus trap, Esc to close, inert page behind.
  useEffect(() => {
    const dialog = dialogRef.current
    if (!dialog) return
    const previous = document.activeElement as HTMLElement | null
    if (!dialog.open) dialog.showModal()
    const scrollLock = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = scrollLock
      if (dialog.open) dialog.close()
      previous?.focus?.()
    }
  }, [])

  // Tracking: the checkout opening is the signal.
  const trackedRef = useRef(false)
  useEffect(() => {
    if (trackedRef.current) return // React StrictMode runs effects twice in dev
    trackedRef.current = true
    const props = productProps(planKey)
    track('view_content', props)
    track('initiate_checkout', props)
    if (planKey === 'deposit') track('deposit_started', props)
  }, [planKey])

  const finish: Finish = useCallback(
    (status, paymentId) => {
      void navigate({
        to: '/thank-you',
        search: { plan: planKey, status, payment: paymentId },
      })
      onClose()
    },
    [navigate, onClose, planKey],
  )

  const titleId = `checkout-title-${planKey}`

  return (
    <dialog
      ref={dialogRef}
      className="sheet"
      aria-labelledby={titleId}
      onCancel={(event) => {
        event.preventDefault()
        onClose()
      }}
    >
      <div
        className="flex h-full w-full items-end justify-center sm:items-center sm:p-6"
        onMouseDown={(event) => {
          if (event.target === event.currentTarget) onClose()
        }}
      >
        <div className="relative flex max-h-full w-full max-w-[34rem] flex-col overflow-hidden rounded-t-2xl border-2 border-navy-900 bg-paper shadow-lift sm:rounded-xl">
          <header className="bg-shingles relative px-5 pt-5 pb-5 text-white sm:px-6" {...productAttrs(planKey)}>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close checkout"
              className="absolute top-3 right-3 grid size-11 place-items-center rounded-md text-white/90 hover:bg-white/15"
            >
              <CloseIcon />
            </button>
            <p className="eyebrow !text-ember-400">{plan.flow === 'deposit' ? 'Secure deposit' : 'Secure checkout'}</p>
            <h2 id={titleId} className="mt-1 pr-10 text-4xl uppercase">
              {plan.title}
            </h2>
            <p className="mt-2 flex items-baseline gap-3">
              <span className="font-display text-4xl font-bold text-ember-400">{formatUsd(plan.price)}</span>
              <span className="text-sm text-white/75">{plan.flow === 'deposit' ? 'credited on your final invoice' : 'one-time'}</span>
            </p>
            <p className="mt-2 max-w-md text-sm text-white/80">{plan.description}</p>
          </header>

          <div className="space-y-5 overflow-y-auto px-5 py-5 sm:px-6">
            {plan.flow === 'deposit' ? (
              <DepositFlow returnUrl={returnUrl} onFinish={finish} />
            ) : (
              <WhopElements elements={getElements()} appearance={elementsAppearance}>
                <ExpressSection planKey={planKey} returnUrl={returnUrl} />
                <Divider>Pay by card &amp; more</Divider>
                <Payments accountId={site.accountId} plan={plan.id} returnUrl={returnUrl}>
                  <PayForm planKey={planKey} returnUrl={returnUrl} onFinish={finish} />
                </Payments>
              </WhopElements>
            )}

            <p className="flex items-start gap-2 text-xs text-ink-soft">
              <LockIcon className="mt-0.5 size-4 shrink-0" />
              <span>
                Payments are processed securely by Whop; card details never touch this site. {site.financing.body}
              </span>
            </p>
          </div>
        </div>
      </div>
    </dialog>
  )
}
