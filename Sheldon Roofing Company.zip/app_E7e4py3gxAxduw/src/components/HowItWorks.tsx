import { formatUsd, getPlan, site } from '#/site.config'
import { productAttrs } from '#/lib/track'
import { useCheckout } from './CheckoutProvider'
import { ArrowIcon, CheckIcon } from './Icons'

export function HowItWorks() {
  const { openCheckout } = useCheckout()
  const deposit = getPlan('deposit')

  return (
    <section id="how-it-works" className="border-y-2 border-navy-900 bg-paper-deep py-16 sm:py-24">
      <div className="wrap">
        <p className="eyebrow">How it works</p>
        <h2 className="h-section mt-2 max-w-3xl">Inspect. Deposit. Job. Final invoice.</h2>
        <p className="mt-4 max-w-2xl text-ink-soft">
          Four steps, each one in writing. You always know what has been paid, what is left and why.
        </p>

        <ol className="relative mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {/* The ridge line connecting the steps */}
          <div
            aria-hidden="true"
            className="absolute top-[1.9rem] right-[12%] left-[12%] hidden h-0.5 bg-navy-900 lg:block"
          />
          {site.steps.map((step, index) => (
            <li key={step.title} className="relative">
              <span className="relative z-10 grid size-[3.8rem] place-items-center rounded-full border-2 border-navy-900 bg-ember-500 font-display text-3xl font-extrabold text-white shadow-[3px_3px_0_var(--color-navy-900)]">
                {index + 1}
              </span>
              <h3 className="mt-4 text-4xl text-navy-900 uppercase">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-soft">{step.text}</p>
            </li>
          ))}
        </ol>

        <div
          {...productAttrs('deposit')}
          className="mt-12 flex flex-col items-start justify-between gap-4 rounded-md border-2 border-navy-900 bg-card p-5 sm:flex-row sm:items-center sm:p-6"
        >
          <div>
            <p className="font-display text-2xl font-bold tracking-wide text-navy-900 uppercase">
              Approved your estimate? Reserve your start date.
            </p>
            <p className="text-sm text-ink-soft">
              {formatUsd(deposit.price)} deposit, credited in full on your final invoice. Secure checkout by Whop.
            </p>
          </div>
          <button type="button" className="btn btn-primary shrink-0" onClick={() => openCheckout('deposit')}>
            {deposit.cta} · {formatUsd(deposit.price)}
          </button>
        </div>

        <FinalBalance />
      </div>
    </section>
  )
}

function FinalBalance() {
  const deposit = getPlan('deposit')
  const example = site.finalInvoice.example
  const balance = example.contractTotal - deposit.price

  return (
    <div id="final-balance" className="mt-16 grid items-center gap-10 lg:grid-cols-[1fr_1.05fr]">
      <div>
        <p className="eyebrow">Billing, explained</p>
        <h3 className="mt-2 text-5xl text-navy-900 uppercase sm:text-6xl">How the final balance is billed</h3>
        <ul className="mt-6 space-y-4">
          {[
            [
              'Your deposit is already paid.',
              `The ${formatUsd(deposit.price)} you paid up front is subtracted. It is never billed twice.`,
            ],
            [
              'One invoice, after the walkthrough.',
              'When the job is finished and you are happy, we send a single invoice for what is left.',
            ],
            [
              'You choose how to pay.',
              'Pay from a secure link in the email, or let us charge the card you saved with Whop when you paid the deposit.',
            ],
          ].map(([title, text]) => (
            <li key={title} className="flex gap-3">
              <span className="mt-1 grid size-6 shrink-0 place-items-center rounded-full bg-navy-900 text-white">
                <CheckIcon className="size-3.5" />
              </span>
              <p className="text-ink-soft">
                <strong className="text-navy-900">{title}</strong> {text}
              </p>
            </li>
          ))}
        </ul>
      </div>

      {/* Example invoice. Sample figures come from site.config. */}
      <figure aria-label="Example final invoice" className="relative">
        <div className="card rotate-[0.6deg] overflow-hidden bg-white">
          <div className="flex items-center justify-between border-b-2 border-navy-900 bg-navy-900 px-5 py-3 text-white">
            <p className="font-display text-2xl font-bold tracking-wide uppercase">Final invoice</p>
            <span className="rounded bg-ember-500 px-2 py-0.5 text-xs font-extrabold tracking-widest uppercase">Example</span>
          </div>
          <div className="space-y-4 p-5 text-sm sm:p-6">
            <p className="text-ink-soft">{example.jobDescription}</p>
            <dl className="divide-y divide-paper-edge">
              <div className="flex justify-between py-2.5">
                <dt className="text-ink-soft">Contract total</dt>
                <dd className="font-semibold text-navy-900">{formatUsd(example.contractTotal, { cents: true })}</dd>
              </div>
              <div className="flex justify-between py-2.5">
                <dt className="flex items-center gap-2 text-ok">
                  <CheckIcon className="size-4" /> Deposit already paid
                </dt>
                <dd className="font-semibold text-ok">−{formatUsd(deposit.price, { cents: true })}</dd>
              </div>
              <div className="flex items-baseline justify-between py-3.5">
                <dt className="font-display text-2xl font-bold tracking-wide text-navy-900 uppercase">Balance due</dt>
                <dd className="font-display text-4xl font-extrabold text-ember-600">{formatUsd(balance, { cents: true })}</dd>
              </div>
            </dl>
            <div className="grid gap-2 sm:grid-cols-2">
              <div className="rounded-md border-2 border-navy-900 px-3 py-2.5">
                <p className="font-bold text-navy-900">Pay by secure link</p>
                <p className="text-xs text-ink-soft">Card, wallets and financing where available</p>
              </div>
              <div className="rounded-md border-2 border-dashed border-navy-300 px-3 py-2.5">
                <p className="flex items-center gap-1.5 font-bold text-navy-900">
                  Charge card on file <ArrowIcon className="size-3.5" />
                </p>
                <p className="text-xs text-ink-soft">Only if you opted in at deposit</p>
              </div>
            </div>
          </div>
        </div>
      </figure>
    </div>
  )
}
