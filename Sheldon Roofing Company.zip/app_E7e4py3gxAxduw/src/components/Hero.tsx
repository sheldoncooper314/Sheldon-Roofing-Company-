import { site } from '#/site.config'
import { useCheckout } from './CheckoutProvider'
import { ArrowIcon } from './Icons'

export function Hero() {
  const { openCheckout } = useCheckout()
  const inspection = site.plans.inspection

  return (
    <section className="relative overflow-hidden border-b-2 border-navy-900">
      {/* Faint ruled lines, like a roofing blueprint */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.55]"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgb(20 33 61 / 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgb(20 33 61 / 0.05) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />

      <div className="wrap relative grid items-center gap-10 py-10 sm:py-14 lg:grid-cols-[1.02fr_1fr] lg:gap-6 lg:py-20">
        <div className="relative z-10">
          <p className="eyebrow flex items-center gap-3">
            <span aria-hidden="true" className="h-0.5 w-8 bg-ember-500" />
            {site.hero.eyebrow}
          </p>
          <h1 className="mt-4 text-[clamp(3.4rem,10.5vw,6.9rem)] leading-[0.9] font-extrabold tracking-[0.005em] text-navy-900 uppercase">
            {site.hero.headline} <span className="relative inline-block text-ember-500">{site.hero.headlineAccent}</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-soft">{site.hero.sub}</p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <a href="#estimate" className="btn btn-primary">
              {site.hero.primaryCta}
              <ArrowIcon className="size-5" />
            </a>
            <button type="button" className="btn btn-ghost" onClick={() => openCheckout('inspection')}>
              {site.hero.secondaryCta}
            </button>
          </div>

          <dl className="mt-10 grid max-w-xl grid-cols-1 gap-0 border-t-2 border-navy-900 sm:grid-cols-3">
            {site.hero.proof.map((item, index) => (
              <div
                key={item.label}
                className={`py-3 sm:px-4 sm:py-4 ${index > 0 ? 'border-t border-paper-edge sm:border-t-0 sm:border-l-2 sm:border-navy-900' : 'sm:pl-0'}`}
              >
                <dt className="font-display text-xl font-bold tracking-wide text-navy-900 uppercase">{item.label}</dt>
                <dd className="text-sm text-ink-soft">{item.value}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative lg:-mr-8">
          {/* Offset navy block behind the photo */}
          <div
            aria-hidden="true"
            className="absolute -right-3 -bottom-3 left-6 top-10 bg-navy-900"
            style={{ clipPath: 'polygon(0 13%, 50% 0, 100% 13%, 100% 100%, 0 100%)' }}
          />
          <div
            className="relative overflow-hidden"
            style={{ clipPath: 'polygon(0 13%, 50% 0, 100% 13%, 100% 100%, 0 100%)' }}
          >
            <img
              src={site.heroImageUrl}
              alt={site.heroImageAlt}
              width={1024}
              height={576}
              fetchPriority="high"
              decoding="async"
              className="aspect-[4/3] w-full object-cover object-[72%_50%] sm:aspect-[16/11]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-950/40 via-transparent to-transparent" />
          </div>

          {/* Price tag: the inspection is the front door to every job */}
          <button
            type="button"
            onClick={() => openCheckout('inspection')}
            className="absolute -bottom-5 left-3 flex min-h-14 items-center gap-3 rounded-md border-2 border-navy-900 bg-card px-4 py-2.5 text-left shadow-[4px_4px_0_var(--color-ember-500)] transition-transform hover:-translate-y-0.5 sm:left-8"
          >
            <span className="font-display text-4xl leading-none font-extrabold text-ember-600">${inspection.price}</span>
            <span className="leading-tight">
              <span className="block font-display text-lg font-bold tracking-wide text-navy-900 uppercase">
                Roof inspection
              </span>
              <span className="block text-xs text-ink-soft">Photo report · book online</span>
            </span>
          </button>
        </div>
      </div>
    </section>
  )
}
