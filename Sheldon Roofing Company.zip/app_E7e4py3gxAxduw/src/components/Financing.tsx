import { site } from '#/site.config'

export function Financing() {
  const f = site.financing
  return (
    <section id="financing" className="py-16 sm:py-20">
      <div className="wrap">
        <div className="relative overflow-hidden rounded-md border-2 border-navy-900 bg-ember-100 p-7 shadow-[6px_6px_0_var(--color-navy-900)] sm:p-10">
          <div
            aria-hidden="true"
            className="absolute -top-16 -right-16 size-56 rounded-full border-[28px] border-ember-500/15"
          />
          <div className="relative grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-center">
            <div>
              <p className="eyebrow">Financing</p>
              <h2 className="mt-2 text-[clamp(2.4rem,5vw,3.8rem)] text-navy-900 uppercase">{f.heading}</h2>
              <p className="mt-4 max-w-xl text-lg font-semibold text-navy-900">{f.body}</p>
              <p className="mt-3 max-w-xl text-sm text-ink-soft">{f.fine}</p>
            </div>
            <div>
              <p className="text-xs font-extrabold tracking-[0.16em] text-ink-soft uppercase">Shown at checkout when available</p>
              <ul className="mt-3 flex flex-wrap gap-2.5">
                {f.providers.map((name) => (
                  <li
                    key={name}
                    className="rounded-md border-2 border-navy-900 bg-white px-4 py-2.5 font-display text-2xl font-bold tracking-wide text-navy-900"
                  >
                    {name}
                  </li>
                ))}
                <li className="rounded-md border-2 border-dashed border-navy-900/50 px-4 py-2.5 font-display text-2xl font-bold tracking-wide text-ink-soft">
                  + more
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
