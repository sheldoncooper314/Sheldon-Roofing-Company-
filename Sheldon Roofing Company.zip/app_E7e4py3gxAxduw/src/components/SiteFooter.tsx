import { site } from '#/site.config'
import { LogoMark } from './SiteHeader'
import { MailIcon, PhoneIcon, PinIcon } from './Icons'

export function SiteFooter() {
  const year = new Date().getFullYear()
  const place = [site.street, `${site.city}, ${site.state}`, site.postalCode].filter(Boolean).join(' ')
  return (
    <footer className="bg-navy-950 text-white/80">
      <div className="wrap grid gap-10 py-14 md:grid-cols-[1.3fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <LogoMark size={52} />
            <p className="font-display text-3xl font-extrabold tracking-wide text-white uppercase">{site.name}</p>
          </div>
          <p className="mt-4 max-w-sm text-sm text-white/65">{site.tagline}</p>
          {site.licenseNumber ? (
            <p className="mt-4 text-sm font-semibold text-white">License # {site.licenseNumber}</p>
          ) : null}
          <p className="mt-1 text-sm text-white/65">Licensed &amp; insured · {site.warrantyYears}-year workmanship warranty</p>
        </div>

        <div>
          <h2 className="font-display text-xl tracking-[0.14em] text-ember-400 uppercase">Contact</h2>
          <ul className="mt-4 space-y-3 text-sm">
            <li>
              <a href={site.phoneHref} className="inline-flex min-h-11 items-center gap-2.5 hover:text-white">
                <PhoneIcon className="size-4 text-ember-400" /> {site.phone}
              </a>
            </li>
            <li>
              <a href={`mailto:${site.email}`} className="inline-flex min-h-11 items-center gap-2.5 hover:text-white">
                <MailIcon className="size-4 text-ember-400" /> {site.email}
              </a>
            </li>
            <li className="flex items-start gap-2.5">
              <PinIcon className="mt-0.5 size-4 shrink-0 text-ember-400" /> {place}
            </li>
            <li className="text-white/60">{site.hours}</li>
          </ul>
        </div>

        <div>
          <h2 className="font-display text-xl tracking-[0.14em] text-ember-400 uppercase">Explore</h2>
          <ul className="mt-4 grid grid-cols-2 gap-x-4 text-sm">
            {[
              ['/#services', 'Services'],
              ['/#how-it-works', 'How it works'],
              ['/#service-area', 'Service area'],
              ['/#financing', 'Financing'],
              ['/#reviews', 'Reviews'],
              ['/#faq', 'FAQ'],
              ['/#estimate', 'Request an estimate'],
            ].map(([href, label]) => (
              <li key={href}>
                <a href={href} className="inline-flex min-h-11 items-center hover:text-white">
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="wrap flex flex-col gap-2 py-5 text-xs text-white/50 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {site.name}. All rights reserved.
          </p>
          <p>
            Payments by Whop · <a href="/admin/final-invoice" className="underline underline-offset-2 hover:text-white">Contractor tool</a>
          </p>
        </div>
      </div>
    </footer>
  )
}
