import { useEffect, useRef, useState } from 'react'
import { formatUsd, getPlan, site, type ServiceConfig } from '#/site.config'
import { productAttrs, productProps, track } from '#/lib/track'
import { useCheckout } from './CheckoutProvider'
import { ArrowIcon, CheckIcon, ChevronIcon, WrenchIcon } from './Icons'

const SERVICES: ServiceConfig[] = site.services

function requestEstimateFor(service: ServiceConfig) {
  window.dispatchEvent(new CustomEvent('estimate:prefill', { detail: { service: service.slug } }))
  document.getElementById('estimate')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

function ServiceDetail({ service, panelId }: { service: ServiceConfig; panelId: string }) {
  const { openCheckout } = useCheckout()
  const plan = service.planKey ? getPlan(service.planKey) : null
  return (
    <div id={panelId} role="region" aria-label={`${service.name} details`} className="grid gap-6 lg:grid-cols-[1.2fr_1fr_1fr]">
      <div>
        <p className="text-base leading-relaxed text-ink">{service.detail}</p>
        <p className="mt-4 inline-flex items-center gap-2 rounded-md bg-paper-deep px-3 py-2 text-sm font-semibold text-navy-900">
          <WrenchIcon className="size-4 text-ember-600" /> {service.timeline}
        </p>
      </div>

      <div>
        <h4 className="font-display text-xl font-bold tracking-wide text-navy-900 uppercase">What is included</h4>
        <ul className="mt-3 space-y-2">
          {service.includes.map((item) => (
            <li key={item} className="flex gap-2.5 text-sm text-ink">
              <CheckIcon className="mt-0.5 size-4 shrink-0 text-ember-600" /> {item}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h4 className="font-display text-xl font-bold tracking-wide text-navy-900 uppercase">Signs you need it</h4>
        <ul className="mt-3 space-y-2">
          {service.signs.map((item) => (
            <li key={item} className="flex gap-2.5 text-sm text-ink">
              <span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-ember-500" /> {item}
            </li>
          ))}
        </ul>
        <div className="mt-5 flex flex-col gap-2 sm:flex-row lg:flex-col xl:flex-row">
          {plan && service.planKey ? (
            <div {...productAttrs(service.planKey)} className="contents">
              <button type="button" className="btn btn-primary btn-sm" onClick={() => openCheckout(service.planKey!)}>
                {plan.cta} · {formatUsd(plan.price)}
              </button>
            </div>
          ) : null}
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => requestEstimateFor(service)}>
            Request an estimate
          </button>
        </div>
      </div>
    </div>
  )
}

export function Services() {
  const [openSlug, setOpenSlug] = useState<string | null>(null)
  const openService = SERVICES.find((s) => s.slug === openSlug) ?? null

  function toggle(service: ServiceConfig) {
    if (openSlug === service.slug) {
      setOpenSlug(null)
      return
    }
    setOpenSlug(service.slug)
    track('service_viewed', { service: service.slug })
    if (service.planKey) track('view_content', productProps(service.planKey))
  }

  return (
    <section id="services" className="py-16 sm:py-24">
      <div className="wrap">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <p className="eyebrow">What we do</p>
            <h2 className="h-section mt-2">Three jobs. Done properly.</h2>
          </div>
          <p className="max-w-md text-ink-soft">
            Open any service to see what is included, the signs you need it and how long it takes.
          </p>
        </div>

        <div className="mt-10 grid items-start gap-6 md:grid-cols-3">
          {SERVICES.map((service, index) => {
            const isOpen = openSlug === service.slug
            const panelId = `service-panel-${service.slug}`
            return (
              <article
                key={service.slug}
                className={`card flex flex-col p-6 transition-all ${isOpen ? 'bg-paper-deep !shadow-[5px_5px_0_var(--color-ember-500)]' : ''}`}
              >
                <div className="flex items-start justify-between">
                  <span className="font-display text-6xl leading-none font-extrabold text-ember-500/90">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  {service.planKey ? (
                    <span className="chip">From {formatUsd(getPlan(service.planKey).price)}</span>
                  ) : null}
                </div>
                <h3 className="mt-3 text-4xl text-navy-900 uppercase">{service.name}</h3>
                <p className="mt-3 text-ink-soft">{service.blurb}</p>
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => toggle(service)}
                  data-service={service.slug}
                  className="btn btn-navy btn-sm mt-6 w-full justify-between"
                >
                  {isOpen ? 'Hide details' : 'See details'}
                  <ChevronIcon className={`size-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* On small screens the detail opens inside its card */}
                {isOpen ? (
                  <div className="mt-6 border-t-2 border-navy-900 pt-6 lg:hidden">
                    <ServiceDetail service={service} panelId={panelId} />
                  </div>
                ) : null}
              </article>
            )
          })}
        </div>

        {/* On large screens the detail opens full width beneath the cards */}
        {openService ? (
          <div className="card mt-8 hidden bg-card p-8 lg:block">
            <div className="mb-5 flex items-center gap-3">
              <span aria-hidden="true" className="h-0.5 w-8 bg-ember-500" />
              <h3 className="text-3xl text-navy-900 uppercase">{openService.name}</h3>
            </div>
            <ServiceDetail service={openService} panelId={`service-panel-${openService.slug}-wide`} />
          </div>
        ) : null}

        <FlatRate />
      </div>
    </section>
  )
}

/** The bookable flat-rate service, with its own buy button. */
function FlatRate() {
  const { openCheckout } = useCheckout()
  const plan = site.plans.tuneUp
  const ref = useRef<HTMLDivElement>(null)

  // view_content once, when the offer scrolls into view.
  useEffect(() => {
    const node = ref.current
    if (!node || typeof IntersectionObserver === 'undefined') return
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          track('view_content', productProps('tuneUp'))
          observer.disconnect()
        }
      },
      { threshold: 0.6 },
    )
    observer.observe(node)
    return () => observer.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      id="tune-up"
      {...productAttrs('tuneUp')}
      className="relative mt-14 overflow-hidden rounded-md border-2 border-navy-900 bg-navy-900 text-white shadow-[6px_6px_0_var(--color-ember-500)]"
    >
      <div className="bg-shingles absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="relative grid gap-8 p-6 sm:p-9 lg:grid-cols-[auto_1fr_auto] lg:items-center">
        <div className="flex items-baseline gap-3 lg:block">
          <p className="eyebrow !text-ember-400">{site.flatRate.eyebrow}</p>
          <p className="font-display text-7xl leading-none font-extrabold text-white sm:text-8xl">
            ${plan.price}
            <span className="ml-2 text-xl font-semibold tracking-widest text-white/60 uppercase">flat</span>
          </p>
        </div>

        <div>
          <h3 className="text-4xl text-white uppercase sm:text-5xl">{plan.title}</h3>
          <p className="mt-3 max-w-xl text-white/75">{plan.description}</p>
          <ul className="mt-4 grid gap-x-6 gap-y-2 sm:grid-cols-2">
            {site.flatRate.includes.map((item) => (
              <li key={item} className="flex gap-2.5 text-sm text-white/90">
                <CheckIcon className="mt-0.5 size-4 shrink-0 text-ember-400" /> {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:text-right">
          <button type="button" className="btn btn-primary w-full lg:w-auto" onClick={() => openCheckout('tuneUp')}>
            {plan.cta}
            <ArrowIcon className="size-5" />
          </button>
          <p className="mt-3 text-xs text-white/60">{site.flatRate.note}</p>
        </div>
      </div>
    </div>
  )
}
