/**
 * ─────────────────────────────────────────────────────────────────────────────
 *  SITE CONFIG — the ONE file that holds everything specific to this business.
 *
 *  To reuse this template for another contractor, edit this file only:
 *  name, phone, service area, services, reviews, FAQ, financing copy,
 *  Whop account id and the three plan ids. Colors and fonts live in
 *  src/styles.css (design tokens). Nothing else needs to change.
 *
 *  Items marked  PLACEHOLDER  are unconfirmed facts. Replace them before
 *  this site goes in front of real customers.
 * ─────────────────────────────────────────────────────────────────────────────
 */

/* ─────────────────────────────── Types ─────────────────────────────────── */

export type PlanKey = 'inspection' | 'deposit' | 'tuneUp'

export interface PlanConfig {
  /** Whop plan id (`plan_…`). This is what the buyer is charged. */
  id: string
  /** Whop product id (`prod_…`). Used for tracking and invoices. */
  productId: string
  title: string
  /** Display price in USD. The charged amount always comes from the Whop plan. */
  price: number
  description: string
  /**
   * `payment`  = one charge through Whop Elements.
   * `deposit`  = save a card with a setup intent, then charge the deposit to it.
   */
  flow: 'payment' | 'deposit'
  /** Label on the button that opens this checkout. */
  cta: string
  /** What happens next, shown on the thank-you page after a successful payment. */
  thanks: string
}

export interface ServiceConfig {
  slug: string
  name: string
  /** One line shown on the card. */
  blurb: string
  /** Longer paragraph shown when the card is opened. */
  detail: string
  includes: string[]
  signs: string[]
  timeline: string
  /** Optional: a bookable plan attached to this service (shows a buy button). */
  planKey?: PlanKey
}

export interface ReviewConfig {
  name: string
  town: string
  rating: 1 | 2 | 3 | 4 | 5
  service: string
  text: string
}

export interface ServiceAreaState {
  name: string
  abbr: string
  cities: string[]
}

export interface FaqItem {
  q: string
  a: string
}

/* ─────────────────────────────── Config ────────────────────────────────── */

export const site = {
  /* ── Identity ─────────────────────────────────────────────────────────── */
  name: 'Sheldon Roofing Company',
  shortName: 'Sheldon Roofing',
  tagline: 'Honest roof work, priced in writing.',
  /** Used for the page <title> and og:title on the home page. */
  seoTitle: 'Sheldon Roofing Company — Roof Repair, Replacement & Inspections',
  seoDescription:
    'Roof repair, full replacements and $149 roof inspections with a written scope and a photo report. Book online, pay a deposit securely, and get a clear final invoice.',

  /** PLACEHOLDER: public site URL once a domain is connected. Leave '' until then. */
  siteUrl: '',

  /* ── Brand assets (absolute URLs) ─────────────────────────────────────── */
  logoUrl:
    'https://assets-2-prod.whop.com/public/uploads/2026-11-13/bc5e1a3b-f4c1-4a01-94f4-c27d17d53c77/image.png',
  heroImageUrl:
    'https://assets-2-prod.whop.com/public/uploads/2026-11-13/5d0e253f-bbc4-4d53-9203-450682748938/image.png',
  heroImageAlt:
    'A Sheldon Roofing crew nailing down architectural shingles on a two-story home at sunset',

  /* ── Contact (PLACEHOLDER values — 555-01xx numbers are reserved for fiction) */
  phone: '(555) 010-0142', // PLACEHOLDER
  phoneHref: 'tel:+15550100142', // PLACEHOLDER — keep in sync with `phone`
  email: 'office@sheldonroofing.example', // PLACEHOLDER
  /** PLACEHOLDER: street address of the office. Leave '' to publish city/state only. */
  street: '',
  city: 'Columbus', // PLACEHOLDER
  state: 'OH', // PLACEHOLDER
  postalCode: '', // PLACEHOLDER
  hours: 'Mon–Fri 7:00am–5:00pm · Sat by appointment', // PLACEHOLDER
  emergencyLine: 'Active leak? Call and we will tarp it the same day when crews are available.', // PLACEHOLDER

  /** PLACEHOLDER: state contractor license number. Shown in the footer when set. */
  licenseNumber: '',

  /* ── Hero ─────────────────────────────────────────────────────────────── */
  hero: {
    eyebrow: 'Roof repair · Replacement · Inspections',
    /** Rendered as headline + accent (accent is set in the orange color). */
    headline: 'A roof you can',
    headlineAccent: 'stop thinking about.',
    sub: 'We inspect first, write the scope down, and price it before a single shingle comes off. Deposits and final balances run through secure Whop checkout, so you always know what you owe and why.',
    primaryCta: 'Request an Estimate',
    secondaryCta: 'Book a $149 inspection',
    /** Short promises shown under the buttons. */
    proof: [
      { label: 'Written scope', value: 'before any work starts' },
      { label: 'Photo report', value: 'with every inspection' },
      { label: 'Deposit credited', value: 'on your final invoice' },
    ],
  },

  /* ── Trust badges (sample — confirm each before launch) ───────────────── */
  trustBadges: [
    { title: 'Licensed', text: 'State-licensed roofing contractor' },
    { title: 'Insured', text: 'General liability and workers’ comp' },
    { title: 'Warrantied', text: 'Written workmanship warranty on every roof' },
    { title: 'In writing', text: 'Scope, price and schedule before we start' },
  ],
  /** PLACEHOLDER: workmanship warranty length used in copy. */
  warrantyYears: 10,

  /* ── Whop ─────────────────────────────────────────────────────────────── */
  accountId: 'biz_LRZNuDZctlQNTf',

  plans: {
    inspection: {
      id: 'plan_Nh8KrDZgMfkC3',
      productId: 'prod_R5OOvah78SawS',
      title: 'Roof inspection',
      price: 149,
      description:
        'A full roof and attic walk-through with a photo report and a written list of findings.',
      flow: 'payment',
      cta: 'Book inspection',
      thanks:
        'You are on the schedule. We will call or email within one business day to confirm a time, then send your photo report after the visit.',
    },
    deposit: {
      id: 'plan_QNheB56FBRj6S',
      productId: 'prod_LrYc2aOhQNnT7',
      title: 'Project deposit',
      price: 500,
      description:
        'Reserves your start date and material order. Credited in full on your final invoice.',
      flow: 'deposit',
      cta: 'Pay project deposit',
      thanks:
        'Your start date and materials are reserved. The full deposit is credited on your final invoice, so you only pay the remaining balance after the walkthrough.',
    },
    tuneUp: {
      id: 'plan_2DNbvKJFdpEIo',
      productId: 'prod_BtgBabEHj8OTM',
      title: 'Gutter Clean & Roof Tune-Up',
      price: 349,
      description:
        'Gutters cleared and flushed, flashing and sealant checked, loose shingles re-secured, roof surface cleared of debris.',
      flow: 'payment',
      cta: 'Book tune-up',
      thanks:
        'You are booked. We will call or email within one business day to pick a date for your tune-up.',
    },
  } satisfies Record<PlanKey, PlanConfig>,

  /**
   * Final balance invoices (see /admin/final-invoice). The custom balance is
   * billed as an inline variant under this product, found or created by its
   * external identifier, so it never touches the deposit product.
   */
  finalInvoice: {
    productExternalId: 'sheldon-roofing-final-balance',
    productTitle: 'Roofing project — final balance',
    /** Days from today until the invoice is due when sent for manual payment. */
    dueInDays: 14,
    /** Shown in the "How the final balance is billed" example on the home page. */
    example: {
      jobDescription: 'Full tear-off and architectural shingle replacement, 28 squares',
      contractTotal: 11450,
    },
  },

  /* ── Services ─────────────────────────────────────────────────────────── */
  services: [
    {
      slug: 'roof-repair',
      name: 'Roof Repair',
      blurb: 'Leaks, lifted shingles, failed flashing and storm damage, fixed at the source.',
      detail:
        'A stain on the ceiling is where the water ended up, not where it got in. We trace the leak back through the deck, repair what actually failed, and tell you plainly if the roof has years left or is on borrowed time.',
      includes: [
        'Leak tracing from attic to roof surface',
        'Shingle, flashing, vent boot and sealant repair',
        'Storm and wind damage documentation with dated photos',
        'Debris haul-off and magnet sweep of the yard',
      ],
      signs: [
        'Water stains or drips after rain',
        'Shingles missing, curled or cracked',
        'Granules collecting in gutters',
        'Daylight visible in the attic',
      ],
      timeline: 'Most repairs are finished in a single visit.',
    },
    {
      slug: 'roof-replacement',
      name: 'Roof Replacement',
      blurb: 'Full tear-off, deck repair and new roof system with a written warranty.',
      detail:
        'We strip to the deck, replace any soft or damaged boards, and rebuild the roof as a system: underlayment, ice and water shield in the valleys, starter strip, shingles, ridge vent. You get a written scope, the material list, and a schedule before you pay a deposit.',
      includes: [
        'Complete tear-off and deck inspection',
        'Underlayment, ice and water shield, drip edge, new flashing',
        'Ventilation check and ridge vent where needed',
        'Daily cleanup and a final magnet sweep',
        'Workmanship warranty in writing',
      ],
      signs: [
        'Roof is 20+ years old',
        'Repairs are becoming frequent',
        'Widespread curling, bald spots or sagging',
        'Insurance has flagged the roof age',
      ],
      timeline: 'Typical home: one to three days on site once materials arrive.',
    },
    {
      slug: 'roof-inspection',
      name: 'Roof Inspection',
      blurb: 'A flat-fee inspection with photos and a plain-English list of findings.',
      detail:
        'Buying a house, filing a claim, or just not sure what is up there? We go over the roof surface, flashings, penetrations, gutters and attic, then send a photo report that separates urgent from can-wait. You pick what, if anything, to do next.',
      includes: [
        'Roof surface, flashing, vents and gutters',
        'Attic check for moisture, ventilation and decking',
        'Photo report with findings ranked by urgency',
        'No-pressure recommendation and a written estimate if you want one',
      ],
      signs: [
        'Buying or selling a home',
        'After a hail or windstorm',
        'Roof is over 15 years old',
        'You want a second opinion on someone else’s quote',
      ],
      timeline: 'Scheduled within days. Report delivered after the visit.',
      planKey: 'inspection',
    },
  ] satisfies ServiceConfig[],

  /** The flat-rate bookable service (uses plans.tuneUp). */
  flatRate: {
    eyebrow: 'Flat-rate service',
    includes: [
      'Gutters cleared and flushed',
      'Flashing and sealant check',
      'Loose shingles re-secured',
      'Roof surface cleared of debris',
    ],
    note: 'One price, no estimate visit. Pick a time after you book.',
  },

  /* ── How it works ─────────────────────────────────────────────────────── */
  steps: [
    {
      title: 'Inspect',
      text: 'We walk the roof and attic, then send a photo report and a written scope. The inspection is a flat $149.',
    },
    {
      title: 'Deposit',
      text: 'Approve the estimate and pay a $500 deposit. It reserves your start date and materials. Your card is saved securely with Whop so the balance can be settled later, if you choose that option.',
    },
    {
      title: 'Job',
      text: 'The crew does the work, cleans up daily, and walks the finished roof with you.',
    },
    {
      title: 'Final invoice',
      text: 'After the walkthrough you get one invoice for the remaining balance. Your deposit is already credited, so you only pay what is left.',
    },
  ],

  /* ── Service area (PLACEHOLDER — replace with the real footprint) ─────── */
  serviceArea: {
    intro:
      'We travel to the metro areas below. Not on the list? Send your ZIP code and we will tell you honestly whether we can get there.',
    states: [
      {
        name: 'Ohio',
        abbr: 'OH',
        cities: ['Columbus', 'Dublin', 'Westerville', 'Delaware', 'Grove City', 'Newark'],
      },
      {
        name: 'Indiana',
        abbr: 'IN',
        cities: ['Indianapolis', 'Carmel', 'Fishers', 'Greenwood', 'Lafayette'],
      },
      {
        name: 'Kentucky',
        abbr: 'KY',
        cities: ['Louisville', 'Lexington', 'Georgetown', 'Elizabethtown'],
      },
      {
        name: 'Tennessee',
        abbr: 'TN',
        cities: ['Nashville', 'Franklin', 'Murfreesboro', 'Hendersonville'],
      },
    ] satisfies ServiceAreaState[],
  },

  /* ── Financing ────────────────────────────────────────────────────────── */
  financing: {
    heading: 'Pay over time, if that suits you better.',
    body: 'Pay over time with Klarna, Afterpay, Affirm and more at checkout, subject to approval.',
    fine: 'Financing options appear automatically in secure checkout when they are available for your order. Approval and terms are decided by each provider, not by us.',
    providers: ['Klarna', 'Afterpay', 'Affirm'],
  },

  /* ── Reviews ──────────────────────────────────────────────────────────── */
  reviews: {
    /** SAMPLE CONTENT. Set to false only after replacing with real customer reviews. */
    isSample: true,
    sampleNote: 'Sample reviews for this demo. Replace with real customer reviews before launch.',
    summary: { rating: 4.9, count: 128 },
    items: [
      {
        name: 'Dana R.',
        town: 'Westerville, OH',
        rating: 5,
        service: 'Roof Replacement',
        text: 'Three quotes, and Sheldon’s was the only one that listed every line item. The crew was done in two days and the yard was cleaner than they found it.',
      },
      {
        name: 'Marcus T.',
        town: 'Carmel, IN',
        rating: 5,
        service: 'Roof Repair',
        text: 'Another company wanted to sell me a new roof for a leak. They found a cracked vent boot, fixed it that afternoon, and showed me the photos.',
      },
      {
        name: 'Priya & Neil K.',
        town: 'Franklin, TN',
        rating: 5,
        service: 'Roof Inspection',
        text: 'We booked the inspection before closing on our house. The report was clear enough to negotiate repairs with the sellers.',
      },
      {
        name: 'Gloria M.',
        town: 'Louisville, KY',
        rating: 4,
        service: 'Gutter Clean & Roof Tune-Up',
        text: 'Easy to book online, fair flat price, and they flagged two loose flashings I would never have noticed. Would call again.',
      },
    ] satisfies ReviewConfig[],
  },

  /* ── FAQ ──────────────────────────────────────────────────────────────── */
  faq: [
    {
      q: 'What does a roof replacement cost?',
      a: 'It depends on roof size, pitch, layers to remove and the material you choose. That is why we inspect first and put the price in writing. You will never be asked for a deposit before you have seen the scope.',
    },
    {
      q: 'What does the $500 deposit cover?',
      a: 'It reserves your spot on the schedule and the material order. It is not an extra fee: the full $500 is credited on your final invoice.',
    },
    {
      q: 'How is the final balance billed?',
      a: 'After the walkthrough we issue one invoice for the remaining balance, with your deposit already subtracted. You can pay it from a secure link, or, if you opted in when you paid the deposit, we can charge the card you saved with Whop.',
    },
    {
      q: 'Can I pay over time?',
      a: 'When you check out online, financing options such as Klarna, Afterpay and Affirm appear automatically if they are available for your order. Approval is decided by the provider.',
    },
    {
      q: 'Do you help with insurance claims?',
      a: 'We document storm damage with dated photos and a written report you can hand to your adjuster, and we are happy to meet them on the roof. We do not negotiate the claim for you.',
    },
    {
      q: 'What warranty do I get?',
      a: 'Every replacement comes with a written workmanship warranty. Shingle manufacturers add their own material warranties on top. Ask for the exact terms in your estimate.',
    },
    {
      q: 'How soon can you come out?',
      a: 'Inspections and tune-ups are usually scheduled within days. Active leaks get priority. Replacements are scheduled around material delivery and weather.',
    },
  ] satisfies FaqItem[],

  /* ── Estimate form ────────────────────────────────────────────────────── */
  estimateForm: {
    heading: 'Tell us about your roof.',
    sub: 'Send the basics and we will reply with next steps within one business day. No spam, no pressure.',
    /** `value` is saved on the lead; keep values stable if reports depend on them. */
    serviceOptions: [
      { value: 'roof-repair', label: 'Roof repair' },
      { value: 'roof-replacement', label: 'Roof replacement' },
      { value: 'roof-inspection', label: 'Roof inspection' },
      { value: 'tune-up', label: 'Gutter clean & roof tune-up' },
      { value: 'not-sure', label: 'Not sure yet' },
    ],
    /** Whop product the lead is attached to by service. Optional. */
    leadProductByService: {
      'roof-inspection': 'prod_R5OOvah78SawS',
      'tune-up': 'prod_BtgBabEHj8OTM',
    } as Record<string, string>,
  },
}

export type Site = typeof site

/* ─────────────────────────────── Helpers ───────────────────────────────── */

export const planList = Object.entries(site.plans).map(([key, plan]) => ({
  key: key as PlanKey,
  ...(plan as PlanConfig),
}))

export function getPlan(key: PlanKey): PlanConfig {
  return site.plans[key]
}

export function isPlanKey(value: unknown): value is PlanKey {
  return typeof value === 'string' && value in site.plans
}

export function formatUsd(amount: number, opts: { cents?: boolean } = {}): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: opts.cents ? 2 : 0,
    maximumFractionDigits: opts.cents ? 2 : 0,
  }).format(amount)
}
