/**
 * Bindings available to server code. Whop injects APP_ID, BUILD_ID and
 * WHOP_API_ORIGIN; every app secret appears here under its own name.
 * The Whop API key itself is attached at the network edge and is never in `env`.
 */
interface AppEnv {
  APP_ID?: string
  BUILD_ID?: string
  WHOP_API_ORIGIN?: string
  /** Not set by the platform. The edge supplies the credential. */
  WHOP_API_KEY?: string
  /** Shared secret for /admin/final-invoice. Set it as an app secret. */
  ADMIN_DEMO_KEY?: string
  /** Optional separate secret used to sign the deposit cookie. Falls back to ADMIN_DEMO_KEY. */
  SESSION_SECRET?: string
}

declare module 'cloudflare:workers' {
  export const env: AppEnv
}
