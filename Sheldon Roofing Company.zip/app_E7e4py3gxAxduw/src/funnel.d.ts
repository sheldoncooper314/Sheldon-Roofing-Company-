import '@tanstack/react-router'

declare module '@tanstack/react-router' {
  interface StaticDataRouteOption {
    /** `pg_` + 12 random letters/digits. Stable for the life of the page. */
    pageId?: string
    /** Arrows drawn from this page on the workspace canvas. */
    funnel?: { next: string[] }
    /** Button label chosen on the canvas for each next step, keyed by path. */
    funnelButtons?: Record<string, string>
  }
}
